#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging
import math
import os
import tempfile

import librosa
import numpy as np
import torch
from decord import cpu
from decord import VideoReader

try:
    from moviepy import VideoFileClip  # moviepy >= 2.0
except ImportError:
    from moviepy.editor import VideoFileClip  # moviepy < 2.0

from PIL import Image

logger = logging.getLogger(__name__)


def streaming_token_decoder(token_iterator, tokenizer, skip_special_tokens=False):
    """
    Incrementally decode tokens from an iterator, handling partial multi-byte characters.

    When streaming tokens, multi-byte characters (like Chinese) may be split across multiple
    tokens. Decoding partial tokens results in replacement characters (U+FFFD). This function
    buffers tokens and only yields complete characters.

    Args:
        token_iterator: An iterator yielding (token_ids, is_finished) tuples.
                       token_ids can be torch.Tensor or any iterable of integers.
        tokenizer: The tokenizer to use for decoding.
        skip_special_tokens: Whether to skip special tokens during decoding.

    Yields:
        (decoded_text, is_finished) tuples where decoded_text is the new text since last yield.
    """
    accumulated_token_ids = []
    yielded_text_len = 0

    for token_ids, is_finished in token_iterator:
        # Accumulate token IDs
        if torch.is_tensor(token_ids):
            accumulated_token_ids.extend(token_ids.reshape(-1).tolist())
        else:
            accumulated_token_ids.extend(list(token_ids) if hasattr(token_ids, "__iter__") else [token_ids])

        # Decode all accumulated tokens
        full_decoded = tokenizer.decode(accumulated_token_ids, skip_special_tokens=skip_special_tokens)

        if is_finished:
            # Final chunk - yield all remaining text
            new_text = full_decoded[yielded_text_len:]
            yield new_text, is_finished
        else:
            # Find safe prefix without incomplete multi-byte characters
            # The replacement character '�' (U+FFFD) indicates incomplete decoding
            new_text = full_decoded[yielded_text_len:]

            # Hold back text ending with replacement character (incomplete UTF-8 sequence)
            safe_end = len(new_text)
            while safe_end > 0 and new_text[safe_end - 1] == "\ufffd":
                safe_end -= 1

            safe_text = new_text[:safe_end] if safe_end > 0 else ""
            yielded_text_len += len(safe_text)
            yield safe_text, is_finished


def torch_clone_recursive(obj):
    """Recursively clone nested containers of torch.Tensors.

    Supported container types: dict, list, tuple. Non-container non-Tensor
    objects are returned as-is.
    """
    if torch.is_tensor(obj):
        return obj.clone()
    elif isinstance(obj, dict):
        return {k: torch_clone_recursive(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [torch_clone_recursive(v) for v in obj]
    elif isinstance(obj, tuple):
        return tuple(torch_clone_recursive(v) for v in obj)
    else:
        raise ValueError(f"Unsupported type: {type(obj)}")


def _fmt_bytes(n_bytes: int) -> str:
    mb = n_bytes / (1024**2)
    return f"{mb:.2f}MB"


def _cuda_tensor_bytes(obj):
    total_bytes = 0
    if torch.is_tensor(obj):
        total_bytes += obj.numel() * obj.element_size()
        print(f"cuda tensor: {obj.shape}, total_bytes: {_fmt_bytes(obj.numel() * obj.element_size())}")
        return total_bytes
    elif isinstance(obj, dict):
        for v in obj.values():
            total_bytes += _cuda_tensor_bytes(v)
        return total_bytes
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            total_bytes += _cuda_tensor_bytes(v)
        return total_bytes
    else:
        raise ValueError(f"Unsupported type: {type(obj)}")


MAX_NUM_FRAMES = int(os.getenv("MAX_NUM_FRAMES", 64))
VIDEO_MME_DURATION = os.getenv("VIDEO_MME_DURATION", "ALL")


def uniform_sample(l, n):
    if len(l) <= n:
        return l
    idxs = np.linspace(0, len(l) - 1, n, dtype=int)
    return [l[i] for i in idxs]


def get_video_frame_audio_segments(video_path, audio_path=None, last_vad_timestamp=None, right_pad_last_segment=True):
    vr = VideoReader(str(video_path), ctx=cpu(0))
    avg_fps = vr.get_avg_fps()
    duration = len(vr) / avg_fps

    if last_vad_timestamp is not None:
        duration = last_vad_timestamp

    if duration > MAX_NUM_FRAMES:
        timestamps = [round(i * 0.1, 1) for i in range(int(duration / 0.1))]
        frame_idx = [min(int(ts * avg_fps), len(vr) - 1) for ts in timestamps]
        frame_idx = uniform_sample(frame_idx, MAX_NUM_FRAMES)
        timestamps = uniform_sample(timestamps, MAX_NUM_FRAMES)
    else:
        num_timestamps = math.ceil(duration)
        frame_idx = [int(i * avg_fps) for i in range(num_timestamps)]
        timestamps = [i for i in range(num_timestamps)]

    video = vr.get_batch(frame_idx).asnumpy()
    video_segments = [Image.fromarray(v.astype("uint8")).convert("RGB") for v in video]

    if audio_path is None:
        try:
            audio_np, sr = librosa.load(video_path, sr=16000, mono=True)
        except:
            video_clip = VideoFileClip(video_path)
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=True) as temp_audio_file:
                temp_audio_file_path = temp_audio_file.name
                video_clip.audio.write_audiofile(temp_audio_file_path, codec="pcm_s16le", fps=16000)
                audio_np, sr = librosa.load(temp_audio_file_path, sr=16000, mono=True)
    else:
        audio_np, sr = librosa.load(audio_path, sr=16000, mono=True)

    # segment audio according to the timestamps
    audio_segments = []
    for i in range(len(timestamps)):
        start_time = timestamps[i]
        if i < len(timestamps) - 1:
            end_time = timestamps[i + 1]
        else:
            end_time = duration

        start_sample = int(start_time * sr)
        end_sample = int(end_time * sr)
        segment = audio_np[start_sample:end_sample]

        # 确保最后一个零头 segment 长度大于 0.1s
        if i == len(timestamps) - 1 and len(segment) < 1600:
            segment = np.concatenate([segment, np.zeros(1600 - len(segment), dtype=segment.dtype)])
        audio_segments.append(segment)

    return video_segments, audio_segments, frame_idx
