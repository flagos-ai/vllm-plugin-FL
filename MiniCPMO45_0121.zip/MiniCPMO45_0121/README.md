
## Deps

- Python 3.12
- Python deps
  ```shell
    pip install \
      "transformers==4.51.0" "torch==2.8.0" "torchaudio==2.8.0" "pytorch-lightning==2.6.0" "lightning==2.6.0" \
      modelscope "onnxruntime-gpu==1.23.2" inflect omegaconf "diffusers==0.31.0" \
      kaldialign librosa pillow decord moviepy openai-whisper hydra-core \
      "pydantic==2.11.7" hyperpyyaml conformer rich gdown matplotlib wget \
      pyarrow pyworld \
      "token2wav-cosyvoice>=0.1.0" "token2wav-cosyvoice-stepaudio2>=0.1.2"
      
  
    MAX_JOBS=16 FLASH_ATTENTION_FORCE_BUILD=TRUE pip install "flash-attn<=2.8.2,>=2.7.1" --no-build-isolation
  
    pip install s3tokenizer  # for streaming
  ```
  
  注:
  - transformers==4.57.0 有一个不兼容的 API 未解决
    - AttributeError: 'DynamicCache' object has no attribute 'get_usable_length'. Did you mean: 'get_seq_length'?
  - 若遇双工 streaming 生成语音卡顿，可先升级 token2wav-cosyvoice-stepaudio2, 更改见 [音频卡顿问题](https://codeup.aliyun.com/thunlp/3rd/stepaudio2/change/3/diffs#file=9a686ab5b41210268c8ca6dfc5664f0cac44ef05) 


## Omni Mode

### Chat Inference

```python

import json
import os

import librosa
import torch
from transformers import AutoTokenizer, AutoProcessor

from MiniCPMO45.modeling_minicpmo import MiniCPMO
from MiniCPMO45.modeling_minicpmo import TTSSamplingParams
from MiniCPMO45.processing_minicpmo import MiniCPMOProcessor
from MiniCPMO45.utils import get_video_frame_audio_segments


def gen():
    ckpts_config = {
        "job_71783_ckpt_3000": {
            "checkpoint_path": "/backup/user/cuijunbo/train/ckpt/minicpm-v/qwen3_preview_o/sft_v1/job_71783_ckpt_3000/minicpm-v_3000.pt",
            "omni_mode": True,
        },
        "job_71958_ckpt_10000": {
            "checkpoint_path": "/backup/user/xubokai/checkpoints_2511/minicpm-v/streaming/ReplaceConvIterV3_AddRewriteZH_EN_BokaiPrompt_Logic_SingleTurnLogicFix_6xConvLogicV2_Add1112SFT_Add1220SFT_MixProfile_AddMT1_streamingFix_HTFix/job_71958_ckpt_10000/minicpm-v_10000.pt",
            "omni_mode": False,
        },
    }

    ref_audio_path = "/user/sunxian/MiniCPM-open/haitian_ref_audio.wav"
    ref_name = "haitian_ref_audio"

    ckpt_name = os.environ.get("CKPT_NAME", "job_71783_ckpt_3000")
    ckpt_config = ckpts_config[ckpt_name]
    checkpoint_path = ckpt_config["checkpoint_path"]
    omni_mode = ckpt_config["omni_mode"]

    save_dir = "/user/sunxian/omni_eval"
    os.makedirs(save_dir, exist_ok=True)
    os.makedirs(os.path.join(save_dir, ckpt_name), exist_ok=True)

    name_or_path = "/backup/user/sunxian/models/MiniCPMO-open/MiniCPM-o-4_5-job_74852_ckpt_4000"
    model = MiniCPMO.from_pretrained(name_or_path, trust_remote_code=True, _attn_implementation="flash_attention_2")

    state_dict = torch.load(checkpoint_path, map_location="cpu")
    miss_keys, unexpected_keys = model.load_state_dict(state_dict, strict=False)
    if miss_keys:
        s = "\n".join(miss_keys)
        print(f"缺失的键: {len(miss_keys)} 个\n{s}")
    if unexpected_keys:
        s = "\n".join(unexpected_keys)
        print(f"意外的键: {len(unexpected_keys)} 个\n{s}")
    print("远程检查点加载完成")

    model.bfloat16()
    model.eval().cuda()

    model.init_tts(streaming=False)

    filenames = {
        "record_cases_info": "/user/wangchongyi/datasets/omni-openqa/record_cases/record_cases_info.jsonl",
        # "all_merged_with_source_and_duration": "/user/wangchongyi/datasets/omni-openqa/sample_cases/all_merged_with_source_and_duration.jsonl",
    }

    use_sys_modes = {
        "omni",
        "audio_assistant",
        "audio_roleplay",
        "voice_cloning",
        "voice_cloning_new",
    }
    use_sys_mode = os.environ.get("USE_SYS_MODE", "no")
    if use_sys_mode not in use_sys_modes:
        use_sys_mode = None

    sys_msg = None
    if use_sys_mode:
        ref_audio, _ = librosa.load(ref_audio_path, sr=16000, mono=True)
        sys_msg = model.get_sys_prompt(ref_audio=ref_audio, mode=use_sys_mode, language="en")

    speedup = int(os.environ.get("SPEEDUP", -1))
    emotion = os.environ.get("EMOTION", "no")
    emotion_map = {
        "happy": "高兴的",
        "sad": "忧伤的",
        "thrilled": "极其激动的",
        "furious": "极其恼怒的",
    }
    emotion_zh = emotion_map.get(emotion, None)

    error_stat = {}
    for name, filename in filenames.items():
        datas = [json.loads(line) for line in open(filename, encoding="utf-8")]
        n_datas = len(datas)
        error_stat[name] = {}

        results = []
        identity_prefix = name
        if use_sys_mode:
            identity_prefix = f"{identity_prefix}_{use_sys_mode}_{ref_name}"
        if speedup > 0:
            identity_prefix = f"{identity_prefix}_{speedup}"
        if emotion_zh:
            identity_prefix = f"{identity_prefix}_{emotion}"

        for id_item, item in enumerate(datas):
            print(f"{id_item}/{n_datas}: {filename}")
            try:
                video_path = item["video_path"]
                if item["source"] == "record_cases":
                    last_vad_timestamp = item["last_vad_timestamp"]
                    video_segments, audio_segments, frame_idx = get_video_frame_audio_segments(
                        video_path, last_vad_timestamp=last_vad_timestamp
                    )
                else:
                    mix_origin_question = item["mix_origin_question"]
                    video_segments, audio_segments, frame_idx = get_video_frame_audio_segments(
                        video_path, audio_path=mix_origin_question
                    )
            except:
                import traceback

                traceback.print_exc()
                print(f"video get frame error, item={item}")
                error_items = error_stat.get(name, {}).get("get_video_frame_audio_segments", [])
                error_items.append(id_item)
                error_stat[name]["get_video_frame_audio_segments"] = error_items
                continue

            omni_segments = []
            if speedup > 0:
                omni_segments.append(f"请以 {speedup} 倍的语速回答问题。")
            if emotion_zh:
                omni_segments.append(f"请以 {emotion_zh} 情感回答问题。")

            for i in range(len(video_segments)):
                omni_segments.append(video_segments[i])
                omni_segments.append(audio_segments[i])

            msgs = []
            if sys_msg:
                msgs.append(sys_msg)

            msgs.append({"role": "user", "content": omni_segments})

            try:
                identity = f"{identity_prefix}_{id_item}"
                output_audio_path = f"{save_dir}/{ckpt_name}/{identity}___generated.wav"
                output_tts_inputs_embeds_path = f"{save_dir}/{ckpt_name}/{identity}___tts_inputs_embeds.pt"

                with torch.no_grad():
                    res, prompt = model.chat(
                        image=None,
                        msgs=msgs,
                        do_sample=True,
                        max_new_tokens=512,
                        max_inp_length=8192,
                        stream=False,
                        stream_input=False,
                        use_tts_template=True,
                        enable_thinking=False,
                        generate_audio=False,
                        output_audio_path=output_audio_path,
                        output_tts_inputs_embeds_path=output_tts_inputs_embeds_path,
                        omni_mode=omni_mode,
                        max_slice_nums=1,
                        use_image_id=False,
                        teacher_forcing=False,
                        return_prompt=True,
                        tts_proj_layer=-1,
                    )

                result = {
                    "idx": id_item,
                    "item": item,
                    "prompt": prompt,
                    "answer": res,
                    "gen_audio_path": output_audio_path,
                }

                if use_sys_mode:
                    result["ref_audio_path"] = ref_audio_path

                results.append(result)
            except:
                import traceback

                traceback.print_exc()
                print(f"error: msgs={msgs}")
                error_items = error_stat.get("items", [])
                error_items.append(id_item)
                error_stat[name]["items"] = error_items

        if results:
            print(f"save into: {save_dir}/{identity_prefix}_{ckpt_name}.jsonl")
            with open(f"{save_dir}/{identity_prefix}_{ckpt_name}.jsonl", "w") as fd:
                for line in results:
                    fd.write(json.dumps(line, ensure_ascii=False) + "\n")
        else:
            print("no data")

        print(error_stat)


if __name__ == "__main__":
    gen()
```

### Streaming Inference

```python
#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import os
import time

import librosa
import numpy as np
import soundfile as sf
import torch
from transformers import AutoTokenizer

from MiniCPMO45.modeling_minicpmo import MiniCPMO
from MiniCPMO45.modeling_minicpmo import TTSSamplingParams
from MiniCPMO45.processing_minicpmo import MiniCPMOProcessor
from MiniCPMO45.utils import get_video_frame_audio_segments


def gen():
    ckpts_config = {
        "job_71783_ckpt_3000": {
            "checkpoint_path": "/backup/user/cuijunbo/train/ckpt/minicpm-v/qwen3_preview_o/sft_v1/job_71783_ckpt_3000/minicpm-v_3000.pt",
            "omni_mode": True,
        },
        "job_71958_ckpt_10000": {
            "checkpoint_path": "/backup/user/xubokai/checkpoints_2511/minicpm-v/streaming/ReplaceConvIterV3_AddRewriteZH_EN_BokaiPrompt_Logic_SingleTurnLogicFix_6xConvLogicV2_Add1112SFT_Add1220SFT_MixProfile_AddMT1_streamingFix_HTFix/job_71958_ckpt_10000/minicpm-v_10000.pt",
            "omni_mode": False,
        },
    }

    ref_audio_path = "/user/sunxian/MiniCPM-open/haitian_ref_audio.wav"
    ref_name = "haitian_ref_audio"

    ckpt_name = os.environ.get("CKPT_NAME", "job_71783_ckpt_3000")
    ckpt_config = ckpts_config[ckpt_name]
    checkpoint_path = ckpt_config["checkpoint_path"]

    save_dir = "/user/sunxian/omni_eval"
    os.makedirs(save_dir, exist_ok=True)
    os.makedirs(os.path.join(save_dir, ckpt_name), exist_ok=True)

    name_or_path = "/user/sunxian/MiniCPM-open/MiniCPM-o-4_5-job_71958_ckpt_10000"
    model = MiniCPMO.from_pretrained(name_or_path, trust_remote_code=True, _attn_implementation="flash_attention_2")

    state_dict = torch.load(checkpoint_path, map_location="cpu")
    miss_keys, unexpected_keys = model.load_state_dict(state_dict, strict=False)
    if miss_keys:
        s = "\n".join(miss_keys)
        print(f"缺失的键: {len(miss_keys)} 个\n{s}")
    if unexpected_keys:
        s = "\n".join(unexpected_keys)
        print(f"意外的键: {len(unexpected_keys)} 个\n{s}")
    print("远程检查点加载完成")

    model.bfloat16()
    model.eval().cuda()

    model.init_tts(streaming=True)

    filenames = {
        "record_cases_info": "/user/wangchongyi/datasets/omni-openqa/record_cases/record_cases_info.jsonl",
        # "all_merged_with_source_and_duration": "/user/wangchongyi/datasets/omni-openqa/sample_cases/all_merged_with_source_and_duration.jsonl",
    }

    use_sys_modes = {
        "omni",
        "audio_assistant",
        "audio_roleplay",
        "voice_cloning",
        "voice_cloning_new",
    }
    use_sys_mode = os.environ.get("USE_SYS_MODE", "no")
    if use_sys_mode not in use_sys_modes:
        use_sys_mode = None

    sys_msg = None
    ref_audio = None
    if use_sys_mode:
        ref_audio, _ = librosa.load(ref_audio_path, sr=16000, mono=True)
        sys_msg = model.get_sys_prompt(ref_audio=ref_audio, mode=use_sys_mode, language="en")

    speedup = int(os.environ.get("SPEEDUP", -1))
    emotion = os.environ.get("EMOTION", "no")
    emotion_map = {
        "happy": "高兴的",
        "sad": "忧伤的",
        "thrilled": "极其激动的",
        "furious": "极其恼怒的",
    }
    emotion_zh = emotion_map.get(emotion, None)

    error_stat = {}
    for name, filename in filenames.items():
        datas = [json.loads(line) for line in open(filename, encoding="utf-8")]
        n_datas = len(datas)
        error_stat[name] = {}

        results = []
        identity_prefix = f"{name}_stream"
        if use_sys_mode:
            identity_prefix = f"{identity_prefix}_{use_sys_mode}_{ref_name}"
        if speedup > 0:
            identity_prefix = f"{identity_prefix}_{speedup}"
        if emotion_zh:
            identity_prefix = f"{identity_prefix}_{emotion}"

        for id_item, item in enumerate(datas):
            model.reset_session()
            session_id = id_item

            # init token2wav buf
            if use_sys_mode and ref_audio is not None:
                model.init_token2wav_cache(prompt_speech_16k=ref_audio)

            generate_audio = True

            print(f"{id_item}/{n_datas}: {filename}")
            try:
                video_path = item["video_path"]
                if item["source"] == "record_cases":
                    last_vad_timestamp = item["last_vad_timestamp"]
                    video_segments, audio_segments, frame_idx = get_video_frame_audio_segments(
                        video_path, last_vad_timestamp=last_vad_timestamp
                    )
                else:
                    mix_origin_question = item["mix_origin_question"]
                    video_segments, audio_segments, frame_idx = get_video_frame_audio_segments(
                        video_path, audio_path=mix_origin_question
                    )
            except:
                import traceback

                traceback.print_exc()
                print(f"video get frame error, item={item}")
                error_items = error_stat.get(name, {}).get("get_video_frame_audio_segments", [])
                error_items.append(id_item)
                error_stat[name]["get_video_frame_audio_segments"] = error_items
                continue

            omni_segments = []
            for i in range(len(video_segments)):
                omni_segments.append(video_segments[i])
                omni_segments.append(audio_segments[i])

            # 如果没有使用 ref_audio 初始化缓存，则用视频的音频片段初始化
            # 拼接前几个片段，确保至少 3 秒（16000 * 3 = 48000 samples）
            if not (use_sys_mode and ref_audio is not None):
                if len(audio_segments) > 0:
                    min_samples = 16000 * 3  # 至少 3 秒
                    prompt_audio = audio_segments[0]
                    for seg in audio_segments[1:]:
                        if len(prompt_audio) >= min_samples:
                            break
                        prompt_audio = np.concatenate([prompt_audio, seg])
                    model.init_token2wav_cache(prompt_speech_16k=prompt_audio)
                else:
                    print(f"Warning: No audio available to init token2wav cache for item {id_item}")

            identity = f"{identity_prefix}_{id_item}"
            output_audio_path = f"{save_dir}/{ckpt_name}/{identity}___generated.wav"

            try:
                prompts = []
                # 1. prefill system prompt
                if sys_msg:
                    cur_prompt = model.streaming_prefill(session_id=session_id, msgs=[sys_msg], omni_mode=True)

                    prompts.append(cur_prompt)

                # 2. prefill omni chunks
                for idx_chunk, content in enumerate(omni_segments, start=1):
                    # 最后一个 segment 一定是 audio，标记为 is_last_chunk
                    is_last_chunk = idx_chunk == len(omni_segments)
                    cur_prompt = model.streaming_prefill(
                        session_id=session_id,
                        msgs=[{"role": "user", "content": [content]}],
                        omni_mode=True,
                        is_last_chunk=is_last_chunk,
                    )

                    prompts.append(cur_prompt)
                print(prompts)

                # 3. generate
                start_time = time.time()
                iter_gen = model.streaming_generate(
                    session_id=session_id,
                    do_sample=True,
                    generate_audio=generate_audio,
                    use_tts_template=True,
                    enable_thinking=False,
                )

                text = ""
                if generate_audio:
                    wav_chunks = []
                    sampling_rate = 24000
                    prev_text_len = 0
                    for idx_chunk, chunk in enumerate(iter_gen):
                        response_time = time.time() - start_time
                        start_time = time.time()
                        print(f"音频块 {idx_chunk} 生成完成 (耗时: {response_time:.2f}s, 形状: {chunk.shape})")
                        wav_chunks.append(chunk)

                        # 实时输出新生成的文本
                        if hasattr(model, "_streaming_generated_text_chunks"):
                            current_text = "".join(model._streaming_generated_text_chunks)
                            new_text = current_text[prev_text_len:]
                            if new_text:
                                print(f"[文本] {new_text}", end="", flush=True)
                            prev_text_len = len(current_text)

                    print()

                    if hasattr(model, "_last_streaming_text") and model._last_streaming_text:
                        text = model._last_streaming_text
                        print(f"[完整文本] {text}")

                    if wav_chunks:
                        generated_waveform = torch.cat(wav_chunks, dim=-1)
                        generated_waveform = generated_waveform[0]
                        sf.write(output_audio_path, generated_waveform.cpu().numpy(), samplerate=sampling_rate)
                else:
                    for r in iter_gen:
                        text += r[0]

                    print("text:", text)

                result = {
                    "idx": id_item,
                    "item": item,
                    "prompt": "\n".join(prompts),
                    "answer": text,
                    "gen_audio_path": output_audio_path,
                }

                if use_sys_mode:
                    result["ref_audio_path"] = ref_audio_path

                results.append(result)
            except:
                import traceback

                traceback.print_exc()
                error_items = error_stat.get("items", [])
                error_items.append(id_item)
                error_stat[name]["items"] = error_items

        if results:
            print(f"save into: {save_dir}/{identity_prefix}_{ckpt_name}.jsonl")
            with open(f"{save_dir}/{identity_prefix}_{ckpt_name}.jsonl", "w") as fd:
                for line in results:
                    fd.write(json.dumps(line, ensure_ascii=False) + "\n")
        else:
            print("no data")

        print(error_stat)


if __name__ == "__main__":
    gen()

```


### Omni-Duplex-Streaming

```python
#!/usr/bin/env python
# -*- coding: utf-8 -*-

import copy
import gc
import json
import logging
import os
import pathlib
import time
from datetime import datetime

import librosa
import numpy as np
import soundfile as sf
import torch
from PIL import Image

from MiniCPMO45.modeling_minicpmo import MiniCPMODuplex
from MiniCPMO45.duplex_utils import generate_duplex_video
from MiniCPMO45.duplex_utils import get_frames_and_audio


logger = logging.getLogger(__name__)


def load_model(ls_mode, checkpoint_path=None, n_timesteps=10):
    logger.info("loading model...")
    name_or_path = "/backup/user/sunxian/models/MiniCPMO-open/MiniCPM-o-4_5-job_74852_ckpt_4000"
    model = MiniCPMODuplex.from_pretrained(
        name_or_path,
        pt_path=checkpoint_path,
        attn_implementation="flash_attention_2",
        vision_batch_size=4,
        audio_pool_step=5,
        audio_chunk_length=1,
        max_slice_nums=9,
        ls_mode=ls_mode,
        n_timesteps=n_timesteps,
    )

    ckpt_name = pathlib.Path(name_or_path).name
    if checkpoint_path is not None:
        ckpt_name = pathlib.Path(checkpoint_path).parent.name
        if "job" not in ckpt_name:
            ckpt_name = pathlib.Path(checkpoint_path).name.split(".pt")[0]

    gc.collect()
    torch.cuda.empty_cache()

    return model, ckpt_name


def eval_duplex_streaming(
    filename,
    media_path,
    output_path,
    checkpoint_path=None,
    has_ref_audio_in_system_prompt=False,
    add_token2wav_ref_audio=True,
    do_sample=False,
    prefix="init",
    n_timesteps=10
):
    model, ckpt_name = load_model(ls_mode="explicit", checkpoint_path=checkpoint_path, n_timesteps=n_timesteps)

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    duplex_output_path = os.path.join(output_path, f"{ckpt_name}_duplex_streaming_{timestamp}")
    os.makedirs(duplex_output_path, exist_ok=True)

    with open(filename, "r", encoding="utf-8") as f:
        data = json.load(f)
    original_data, datas = data, data["tasks"]

    sys_prompt_text = "Streaming Omni Conversation."
    prefix_system_prompt = f"<|im_start|>system\n{sys_prompt_text}"
    suffix_system_prompt = "<|im_end|>"

    decode_mode = "sampling" if do_sample else "greedy"
    if decode_mode == "greedy":
        generation_config = {
            "temperature": 1.0,
            "top_k": -1,
            "top_p": 1.0,
            "listen_top_k": None,
            "listen_prob_scale": 1.0,
            "text_repetition_penalty": 1.0,
        }
    else:
        generation_config = {
            "temperature": 0.7,
            "top_k": 100,
            "top_p": 0.8,
            "listen_top_k": None,
            "listen_prob_scale": 1.0,
            "text_repetition_penalty": 1.05,
        }

    ref_audio_path = "/user/sunxian/MiniCPM-open/haitian_ref_audio.wav"

    identity_prefix = f"{prefix}_eval_duplex_streaming_{decode_mode}_ref_audio_in_sys{has_ref_audio_in_system_prompt}"

    sample_rate = 16000

    results = []
    error_info = []
    n_failed = 0
    for idx_item, item in enumerate(datas, start=1):
        logger.info(f"{idx_item}/{len(datas)}, failed: {n_failed}/{len(datas)}")

        item_output_dir = os.path.join(duplex_output_path, f"item_{idx_item}")
        os.makedirs(item_output_dir, exist_ok=True)
        frame_audio_path_item = item_output_dir

        try:
            logger.info(f"get frames and audio...")
            video_path_raw = item["video_path"].lstrip("./")
            video_path = os.path.join(media_path, video_path_raw)
            logger.info(f"Processing video: {video_path}")

            # 使用与 offline 相同的数据预处理方式
            frame_path, num_frames, audio_path = get_frames_and_audio(
                video_path, frame_audio_path_item, sample_rate=sample_rate
            )
            logger.info(f"Extracted {num_frames} frames to {frame_path}, audio to {audio_path}")

            # 从保存的帧文件中加载 video_segments
            frame_files = sorted([f for f in os.listdir(frame_path) if f.endswith(".jpg")])
            video_segments = [Image.open(os.path.join(frame_path, f)).convert("RGB") for f in frame_files]
            logger.info(f"Loaded {len(video_segments)} video frames from {frame_path}")

            # 从保存的音频文件中加载并分段为 audio_segments
            audio_array, _ = librosa.load(audio_path, sr=sample_rate, mono=True)
            audio_segments = [audio_array[i * sample_rate : (i + 1) * sample_rate] for i in range(num_frames)]
            logger.info(f"Loaded {len(audio_segments)} audio segments from {audio_path}")

            model.prepare(
                prefix_system_prompt=prefix_system_prompt,
                suffix_system_prompt=suffix_system_prompt,
                ref_audio=None,
                prompt_wav_path=ref_audio_path,
            )

            num_chunks = len(audio_segments)
            logger.info(
                f"Total audio duration: {len(audio_array) / sample_rate:.2f}s, will process {num_chunks} chunks"
            )

            all_output_audio = []
            timed_output_audio = []  # 记录 (chunk_idx, audio_waveform) 用于时间对齐
            results_log = []
            all_prefill_times = []
            all_generate_times = []
            all_chunk_times = []  # (chunk_time, num_tokens) 用于计算排除 token<=1 的平均
            all_cost_llm = []
            all_cost_tts_prep = []
            all_cost_tts = []
            all_cost_token2wav = []
            all_cost_all = []
            all_n_tokens = []
            # prefill 细分耗时
            all_prefill_vision_process = []
            all_prefill_vision_embed = []
            all_prefill_vision_feed = []
            all_prefill_audio_process = []
            all_prefill_audio_embed = []
            all_prefill_audio_feed = []

            generate_start_time = time.time()
            track_info = {}
            for chunk_idx in range(num_chunks):
                audio_chunk = audio_segments[chunk_idx]
                frame = video_segments[chunk_idx] if chunk_idx < len(video_segments) else None
                frame_list = [frame] if frame is not None else None

                # 1. streaming_prefill
                prefill_result = model.streaming_prefill(
                    audio_waveform=audio_chunk,
                    frame_list=frame_list,
                )
                prefill_success = (
                    prefill_result.get("success", False) if isinstance(prefill_result, dict) else prefill_result
                )
                prefill_time = prefill_result.get("cost_all", 0.0) if isinstance(prefill_result, dict) else 0.0
                all_prefill_times.append(prefill_time)

                # 收集 prefill 细分耗时
                if isinstance(prefill_result, dict):
                    all_prefill_vision_process.append(prefill_result.get("cost_vision_process", 0.0))
                    all_prefill_vision_embed.append(prefill_result.get("cost_vision_embed", 0.0))
                    all_prefill_vision_feed.append(prefill_result.get("cost_vision_feed", 0.0))
                    all_prefill_audio_process.append(prefill_result.get("cost_audio_process", 0.0))
                    all_prefill_audio_embed.append(prefill_result.get("cost_audio_embed", 0.0))
                    all_prefill_audio_feed.append(prefill_result.get("cost_audio_feed", 0.0))

                if not prefill_success:
                    logger.warning(f"Prefill failed for chunk {chunk_idx}")
                    continue

                # 2. streaming_generate
                generate_start = time.time()
                result = model.streaming_generate(
                    prompt_wav_path=ref_audio_path,
                    max_new_speak_tokens_per_chunk=20,
                    decode_mode=decode_mode,
                    **generation_config,
                )
                generate_time = time.time() - generate_start
                all_generate_times.append(generate_time)

                # 收集 streaming_generate 内部的耗时统计
                cost_llm = result.get("cost_llm", 0.0)
                cost_tts_prep = result.get("cost_tts_prep", 0.0)
                cost_tts = result.get("cost_tts", 0.0)
                cost_token2wav = result.get("cost_token2wav", 0.0)
                cost_all = result.get("cost_all", 0.0)
                n_tokens = result.get("n_tokens", 0)
                all_cost_llm.append(cost_llm)
                all_cost_tts_prep.append(cost_tts_prep)
                all_cost_tts.append(cost_tts)
                all_cost_token2wav.append(cost_token2wav)
                all_cost_all.append(cost_all)
                all_n_tokens.append(n_tokens)

                # 记录 chunk 时间和生成的 token 数量（用于计算排除 token<=1 的平均）
                chunk_time = prefill_time + generate_time
                all_chunk_times.append((chunk_time, n_tokens))

                chunk_result = {
                    "chunk_idx": chunk_idx,
                    "is_listen": result["is_listen"],
                    "text": result["text"],
                    "end_of_turn": result["end_of_turn"],
                    "current_time": result["current_time"],
                    "audio_length": len(result["audio_waveform"]) if result["audio_waveform"] is not None else 0,
                }
                results_log.append(chunk_result)

                if result["audio_waveform"] is not None:
                    all_output_audio.append(result["audio_waveform"])
                    timed_output_audio.append((chunk_idx, result["audio_waveform"]))

            generate_elapsed_time = time.time() - generate_start_time
            avg_chunk_time = generate_elapsed_time / num_chunks if num_chunks > 0 else 0
            avg_prefill_time = sum(all_prefill_times) / len(all_prefill_times) if all_prefill_times else 0
            avg_generate_time = sum(all_generate_times) / len(all_generate_times) if all_generate_times else 0
            # 计算排除 token<=1 的 chunk 的平均时间
            valid_chunk_times = [t for t, n in all_chunk_times if n > 1]
            avg_chunk_time_valid = sum(valid_chunk_times) / len(valid_chunk_times) if valid_chunk_times else 0
            all_chunk_times_only = [t for t, n in all_chunk_times]
            max_chunk_time = max(all_chunk_times_only) if all_chunk_times_only else 0
            min_chunk_time = min(all_chunk_times_only) if all_chunk_times_only else 0

            logger.info(
                f"streaming generate elapsed time: {generate_elapsed_time:.2f}s, avg chunk time: {avg_chunk_time:.3f}s"
            )
            logger.info(
                f"avg chunk time (token>1): {avg_chunk_time_valid:.3f}s ({len(valid_chunk_times)}/{len(all_chunk_times)} chunks)"
            )
            logger.info(f"max chunk time: {max_chunk_time:.3f}s, min chunk time: {min_chunk_time:.3f}s")
            logger.info(f"avg prefill time: {avg_prefill_time:.3f}s, avg generate time: {avg_generate_time:.3f}s")
            # streaming_prefill 细分耗时统计
            avg_prefill_vision_process = (
                sum(all_prefill_vision_process) / len(all_prefill_vision_process) if all_prefill_vision_process else 0
            )
            avg_prefill_vision_embed = (
                sum(all_prefill_vision_embed) / len(all_prefill_vision_embed) if all_prefill_vision_embed else 0
            )
            avg_prefill_vision_feed = (
                sum(all_prefill_vision_feed) / len(all_prefill_vision_feed) if all_prefill_vision_feed else 0
            )
            avg_prefill_audio_process = (
                sum(all_prefill_audio_process) / len(all_prefill_audio_process) if all_prefill_audio_process else 0
            )
            avg_prefill_audio_embed = (
                sum(all_prefill_audio_embed) / len(all_prefill_audio_embed) if all_prefill_audio_embed else 0
            )
            avg_prefill_audio_feed = (
                sum(all_prefill_audio_feed) / len(all_prefill_audio_feed) if all_prefill_audio_feed else 0
            )
            logger.info(
                f"[streaming_prefill] avg vision: process={avg_prefill_vision_process:.3f}s, embed={avg_prefill_vision_embed:.3f}s, feed={avg_prefill_vision_feed:.3f}s"
            )
            logger.info(
                f"[streaming_prefill] avg audio: process={avg_prefill_audio_process:.3f}s, embed={avg_prefill_audio_embed:.3f}s, feed={avg_prefill_audio_feed:.3f}s"
            )
            # streaming_generate 内部耗时统计
            avg_cost_llm = sum(all_cost_llm) / len(all_cost_llm) if all_cost_llm else 0
            avg_cost_tts_prep = sum(all_cost_tts_prep) / len(all_cost_tts_prep) if all_cost_tts_prep else 0
            avg_cost_tts = sum(all_cost_tts) / len(all_cost_tts) if all_cost_tts else 0
            avg_cost_token2wav = sum(all_cost_token2wav) / len(all_cost_token2wav) if all_cost_token2wav else 0
            avg_cost_all = sum(all_cost_all) / len(all_cost_all) if all_cost_all else 0
            total_n_tokens = sum(all_n_tokens)
            logger.info(
                f"[streaming_generate] avg cost_llm: {avg_cost_llm:.3f}s, avg cost_tts_prep: {avg_cost_tts_prep:.3f}s, avg cost_tts: {avg_cost_tts:.3f}s, avg cost_token2wav: {avg_cost_token2wav:.3f}s"
            )
            logger.info(f"[streaming_generate] avg cost_all: {avg_cost_all:.3f}s, total tokens: {total_n_tokens}")

            # 保存 chunk 级别结果
            results_path = os.path.join(item_output_dir, "chunk_results.json")
            with open(results_path, "w", encoding="utf-8") as f:
                json.dump(results_log, f, ensure_ascii=False, indent=2)
            logger.info(f"Chunk results saved to {results_path}")

            # 合并并保存输出音频
            if all_output_audio:
                output_audio = np.concatenate(all_output_audio)
                output_audio_path = os.path.join(item_output_dir, "output_audio.wav")
                sf.write(
                    output_audio_path,
                    (output_audio * 32768).astype(np.int16),
                    24000,
                    subtype="PCM_16",
                )
                logger.info(f"Output audio saved to {output_audio_path}")

                # 生成立体声音频：左声道=用户输入，右声道=AI回复（时间对齐）
                input_audio_24k = librosa.resample(audio_array, orig_sr=16000, target_sr=24000)

                output_sample_rate = 24000
                samples_per_chunk = output_sample_rate  # 每个 chunk 对应 1 秒 = 24000 样本

                # 计算右声道需要的最大长度
                max_right_len = 0
                for c_idx, audio in timed_output_audio:
                    end_pos = c_idx * samples_per_chunk + len(audio)
                    max_right_len = max(max_right_len, end_pos)

                max_len = max(len(input_audio_24k), max_right_len)

                left_channel = np.zeros(max_len, dtype=np.float32)
                right_channel = np.zeros(max_len, dtype=np.float32)

                # 左声道：用户输入
                left_channel[: len(input_audio_24k)] = input_audio_24k

                # 右声道：AI 回复（按 chunk 时间位置放置）
                for c_idx, audio in timed_output_audio:
                    start_pos = c_idx * samples_per_chunk
                    end_pos = start_pos + len(audio)
                    right_channel[start_pos:end_pos] += audio

                right_channel = np.clip(right_channel, -1.0, 1.0)

                stereo_audio = np.stack([left_channel, right_channel], axis=1)
                joint_audio_path = os.path.join(item_output_dir, "joint_audio.wav")
                sf.write(
                    joint_audio_path,
                    (stereo_audio * 32768).astype(np.int16),
                    24000,
                    subtype="PCM_16",
                )
                logger.info(f"Joint stereo audio saved to {joint_audio_path}")

            # 生成带有双工回复的视频
            output_video_path = os.path.join(item_output_dir, "duplex_output.mp4")
            try:
                generate_duplex_video(
                    video_path=video_path,
                    output_video_path=output_video_path,
                    results_log=results_log,
                    timed_output_audio=timed_output_audio,
                    output_sample_rate=24000,
                )
            except Exception as e:
                logger.error(f"Failed to generate duplex video: {e}")
                import traceback

                traceback.print_exc()
                output_video_path = None

            # 保存结果
            generated_text = model.get_generated_text()
            item_result = copy.deepcopy(item)
            item_result["video_path"] = video_path
            item_result["generated_text"] = generated_text
            item_result["output_dir"] = item_output_dir
            item_result["ref_audio_path"] = ref_audio_path
            item_result["num_chunks"] = num_chunks
            item_result["chunk_results"] = results_log
            item_result["output_video_path"] = output_video_path
            item_result["generate_elapsed_time"] = generate_elapsed_time
            item_result["avg_chunk_time"] = avg_chunk_time
            item_result["avg_chunk_time_valid"] = avg_chunk_time_valid
            item_result["max_chunk_time"] = max_chunk_time
            item_result["min_chunk_time"] = min_chunk_time
            item_result["avg_prefill_time"] = avg_prefill_time
            item_result["avg_prefill_vision_process"] = avg_prefill_vision_process
            item_result["avg_prefill_vision_embed"] = avg_prefill_vision_embed
            item_result["avg_prefill_vision_feed"] = avg_prefill_vision_feed
            item_result["avg_prefill_audio_process"] = avg_prefill_audio_process
            item_result["avg_prefill_audio_embed"] = avg_prefill_audio_embed
            item_result["avg_prefill_audio_feed"] = avg_prefill_audio_feed
            item_result["avg_generate_time"] = avg_generate_time
            item_result["avg_cost_llm"] = avg_cost_llm
            item_result["avg_cost_tts_prep"] = avg_cost_tts_prep
            item_result["avg_cost_tts"] = avg_cost_tts
            item_result["avg_cost_token2wav"] = avg_cost_token2wav
            item_result["avg_cost_all"] = avg_cost_all
            item_result["total_n_tokens"] = total_n_tokens

            results.append(item_result)

            # 保存单个样本的详细结果
            item_result_path = os.path.join(item_output_dir, "result.json")
            with open(item_result_path, "w", encoding="utf-8") as f:
                json.dump(item_result, f, ensure_ascii=False, indent=2)
            logger.info(f"Item result saved to {item_result_path}")

            logger.info(f"Generated text: {generated_text}")

        except Exception:
            import traceback

            traceback.print_exc()
            error_info.append(item)
            n_failed += 1

    # 保存所有结果
    if results:
        filename_result = os.path.join(output_path, f"{identity_prefix}_{ckpt_name}_{timestamp}.json")
        output_data = copy.deepcopy(original_data)
        result_map = {r.get("id"): r for r in results}
        for task in output_data["tasks"]:
            task_id = task.get("id")
            if task_id in result_map:
                r = result_map[task_id]
                task["video_path"] = r["video_path"]
                task["generated_text"] = r["generated_text"]
                task["output_dir"] = r["output_dir"]
                task["ref_audio_path"] = r["ref_audio_path"]
                task["num_chunks"] = r["num_chunks"]
                task["chunk_results"] = r["chunk_results"]
                task["output_video_path"] = r.get("output_video_path")
                task["generate_elapsed_time"] = r["generate_elapsed_time"]
                task["avg_chunk_time"] = r["avg_chunk_time"]
                task["avg_chunk_time_valid"] = r["avg_chunk_time_valid"]
                task["max_chunk_time"] = r["max_chunk_time"]
                task["min_chunk_time"] = r["min_chunk_time"]
                task["avg_prefill_time"] = r["avg_prefill_time"]
                task["avg_prefill_vision_process"] = r["avg_prefill_vision_process"]
                task["avg_prefill_vision_embed"] = r["avg_prefill_vision_embed"]
                task["avg_prefill_vision_feed"] = r["avg_prefill_vision_feed"]
                task["avg_prefill_audio_process"] = r["avg_prefill_audio_process"]
                task["avg_prefill_audio_embed"] = r["avg_prefill_audio_embed"]
                task["avg_prefill_audio_feed"] = r["avg_prefill_audio_feed"]
                task["avg_generate_time"] = r["avg_generate_time"]
                task["avg_cost_llm"] = r["avg_cost_llm"]
                task["avg_cost_tts_prep"] = r["avg_cost_tts_prep"]
                task["avg_cost_tts"] = r["avg_cost_tts"]
                task["avg_cost_token2wav"] = r["avg_cost_token2wav"]
                task["avg_cost_all"] = r["avg_cost_all"]
                task["total_n_tokens"] = r["total_n_tokens"]
        logger.info(f"save results into: {filename_result}")
        output_data["metadata"]["generate_method"] = "streaming"
        output_data["metadata"]["has_ref_audio_in_system_prompt"] = has_ref_audio_in_system_prompt
        output_data["metadata"]["add_token2wav_ref_audio"] = add_token2wav_ref_audio
        output_data["metadata"]["do_sample"] = do_sample
        with open(filename_result, "w", encoding="utf-8") as fd:
            json.dump(output_data, fd, ensure_ascii=False, indent=2)
    else:
        logger.error("no results")

    if error_info:
        error_path = os.path.join(duplex_output_path, "errors.json")
        with open(error_path, "w", encoding="utf-8") as f:
            json.dump(error_info, f, ensure_ascii=False, indent=2)
        logger.error(f"error_info saved to: {error_path}")

    logger.info(f"failed: {n_failed}/{len(datas)}")
    logger.info(f"results saved to: {duplex_output_path}")

    # 打印所有样本的平均 chunk 时间
    if results:
        all_avg_chunk_times = [r["avg_chunk_time"] for r in results]
        all_avg_chunk_times_valid = [r["avg_chunk_time_valid"] for r in results if r["avg_chunk_time_valid"] > 0]
        all_max_chunk_times = [r["max_chunk_time"] for r in results]
        all_min_chunk_times = [r["min_chunk_time"] for r in results]
        all_avg_prefill_times = [r["avg_prefill_time"] for r in results]
        all_avg_generate_times = [r["avg_generate_time"] for r in results]
        overall_avg_chunk_time = sum(all_avg_chunk_times) / len(all_avg_chunk_times)
        overall_avg_chunk_time_valid = (
            sum(all_avg_chunk_times_valid) / len(all_avg_chunk_times_valid) if all_avg_chunk_times_valid else 0
        )
        overall_max_chunk_time = max(all_max_chunk_times) if all_max_chunk_times else 0
        overall_min_chunk_time = min(all_min_chunk_times) if all_min_chunk_times else 0
        overall_avg_prefill_time = sum(all_avg_prefill_times) / len(all_avg_prefill_times)
        overall_avg_generate_time = sum(all_avg_generate_times) / len(all_avg_generate_times)
        logger.info(f"Overall avg chunk time across {len(results)} samples: {overall_avg_chunk_time:.3f}s")
        logger.info(f"Overall avg chunk time (token>1): {overall_avg_chunk_time_valid:.3f}s")
        logger.info(
            f"Overall max chunk time: {overall_max_chunk_time:.3f}s, min chunk time: {overall_min_chunk_time:.3f}s"
        )
        logger.info(
            f"Overall avg prefill time: {overall_avg_prefill_time:.3f}s, avg generate time: {overall_avg_generate_time:.3f}s"
        )
        # streaming_prefill 细分耗时汇总
        all_avg_prefill_vision_process = [r["avg_prefill_vision_process"] for r in results]
        all_avg_prefill_vision_embed = [r["avg_prefill_vision_embed"] for r in results]
        all_avg_prefill_vision_feed = [r["avg_prefill_vision_feed"] for r in results]
        all_avg_prefill_audio_process = [r["avg_prefill_audio_process"] for r in results]
        all_avg_prefill_audio_embed = [r["avg_prefill_audio_embed"] for r in results]
        all_avg_prefill_audio_feed = [r["avg_prefill_audio_feed"] for r in results]
        overall_avg_prefill_vision_process = sum(all_avg_prefill_vision_process) / len(all_avg_prefill_vision_process)
        overall_avg_prefill_vision_embed = sum(all_avg_prefill_vision_embed) / len(all_avg_prefill_vision_embed)
        overall_avg_prefill_vision_feed = sum(all_avg_prefill_vision_feed) / len(all_avg_prefill_vision_feed)
        overall_avg_prefill_audio_process = sum(all_avg_prefill_audio_process) / len(all_avg_prefill_audio_process)
        overall_avg_prefill_audio_embed = sum(all_avg_prefill_audio_embed) / len(all_avg_prefill_audio_embed)
        overall_avg_prefill_audio_feed = sum(all_avg_prefill_audio_feed) / len(all_avg_prefill_audio_feed)
        logger.info(
            f"[streaming_prefill] Overall avg vision: process={overall_avg_prefill_vision_process:.3f}s, embed={overall_avg_prefill_vision_embed:.3f}s, feed={overall_avg_prefill_vision_feed:.3f}s"
        )
        logger.info(
            f"[streaming_prefill] Overall avg audio: process={overall_avg_prefill_audio_process:.3f}s, embed={overall_avg_prefill_audio_embed:.3f}s, feed={overall_avg_prefill_audio_feed:.3f}s"
        )
        # streaming_generate 内部耗时汇总
        all_avg_cost_llm = [r["avg_cost_llm"] for r in results]
        all_avg_cost_tts_prep = [r["avg_cost_tts_prep"] for r in results]
        all_avg_cost_tts = [r["avg_cost_tts"] for r in results]
        all_avg_cost_token2wav = [r["avg_cost_token2wav"] for r in results]
        all_avg_cost_all = [r["avg_cost_all"] for r in results]
        all_total_n_tokens = [r["total_n_tokens"] for r in results]
        overall_avg_cost_llm = sum(all_avg_cost_llm) / len(all_avg_cost_llm)
        overall_avg_cost_tts_prep = sum(all_avg_cost_tts_prep) / len(all_avg_cost_tts_prep)
        overall_avg_cost_tts = sum(all_avg_cost_tts) / len(all_avg_cost_tts)
        overall_avg_cost_token2wav = sum(all_avg_cost_token2wav) / len(all_avg_cost_token2wav)
        overall_avg_cost_all = sum(all_avg_cost_all) / len(all_avg_cost_all)
        overall_total_n_tokens = sum(all_total_n_tokens)
        logger.info(
            f"[streaming_generate] Overall avg cost_llm: {overall_avg_cost_llm:.3f}s, avg cost_tts_prep: {overall_avg_cost_tts_prep:.3f}s, avg cost_tts: {overall_avg_cost_tts:.3f}s, avg cost_token2wav: {overall_avg_cost_token2wav:.3f}s"
        )
        logger.info(
            f"[streaming_generate] Overall avg cost_all: {overall_avg_cost_all:.3f}s, total tokens: {overall_total_n_tokens}"
        )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--filename", type=str)
    parser.add_argument("--media_path", type=str)
    parser.add_argument("--output_path", type=str)
    parser.add_argument("--checkpoint_path", type=str, default=None)
    parser.add_argument("--prefix", type=str, default="init")
    parser.add_argument("--n_timesteps", type=int, default=5)

    args = parser.parse_args()

    args.filename = (
        "/user/sunxian/MiniCPM-open/benchmark-demo/omni_demo_collect_final/omni_demo_zh_duplex/zh-duplex.json"
    )
    args.media_path = "/user/sunxian/MiniCPM-open/benchmark-demo/omni_demo_collect_final/omni_demo_zh_duplex/"
    args.output_path = "/user/sunxian/omni_eval"
    args.checkpoint_path = "/backup/user/xuxingjing/checkpoints/minicpm-v/45opost/duplex/0108/decay_0110_duplex/job_76675_ckpt_600/minicpm-v_600.pt"

    eval_duplex_streaming(args.filename, args.media_path, args.output_path, args.checkpoint_path, args.prefix)
```