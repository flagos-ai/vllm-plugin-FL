#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import logging
import math
import tempfile
import uuid
from collections.abc import Iterator
from copy import deepcopy
from dataclasses import dataclass
from typing import List
from typing import Optional
from typing import Tuple
from typing import Union

import numpy as np
import soundfile as sf
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.utils.parametrize as P
from PIL import Image
from pydantic import BaseModel
from torch.nn.utils.parametrizations import weight_norm
from tqdm import tqdm
from transformers import LlamaConfig
from transformers import LlamaModel
from transformers import PreTrainedModel
from transformers import Qwen3ForCausalLM
from transformers import Qwen3PreTrainedModel
from transformers.activations import ACT2FN
from transformers.cache_utils import DynamicCache
from transformers.cache_utils import EncoderDecoderCache
from transformers.generation.logits_process import MinPLogitsWarper
from transformers.generation.logits_process import RepetitionPenaltyLogitsProcessor
from transformers.generation.logits_process import TopKLogitsWarper
from transformers.generation.logits_process import TopPLogitsWarper
from transformers.modeling_outputs import BaseModelOutputWithPast
from transformers.modeling_outputs import ModelOutput
from transformers.models.whisper.configuration_whisper import WhisperConfig
from transformers.models.whisper.modeling_whisper import WhisperEncoder

from .chunk_prefill_generate import ChunkPrefillChunkGenerate
from .configuration_minicpmo import MiniCPMOConfig
from .configuration_minicpmtts import MiniCPMTTSConfig
from .modeling_navit_siglip import SiglipVisionTransformer
from .resampler import Resampler
from .tts_streaming_generate import TTSStreamingGenerator
from .utils import _cuda_tensor_bytes
from .utils import _fmt_bytes
from .utils import torch_clone_recursive

logger = logging.getLogger(__name__)


@dataclass
class OmniOutput(ModelOutput):
    text: Optional[Union[str, List[str], Iterator]] = None
    spk_embeds: Optional[torch.FloatTensor] = None
    audio_wav: Optional[np.ndarray] = None
    sampling_rate: Optional[int] = None


class TTSSamplingParams(BaseModel):
    top_p: float = 0.85
    min_p: float = 0.01
    top_k: int = 25
    repetition_penalty: float = 1.05
    temperature: float = 0.8
    win_size: int = 16
    tau_r: float = 0.1


class MiniCPMOPreTrainedModel(Qwen3PreTrainedModel):
    config_class = MiniCPMOConfig


class MiniCPMO(MiniCPMOPreTrainedModel):
    def __init__(self, config):
        super().__init__(config)

        self.llm = Qwen3ForCausalLM(config)
        self.embed_dim = self.llm.config.hidden_size

        # init vision module
        if self.config.init_vision:
            self.vpm = self.init_vision_module()
            self.vision_dim = self.vpm.embed_dim
            self.resampler = self.init_resampler(self.embed_dim, self.vision_dim)

        # init audio module
        if self.config.init_audio:
            self.apm = self.init_audio_module()
            audio_output_dim = int(self.apm.config.encoder_ffn_dim // 4)
            self.audio_avg_pooler = nn.AvgPool1d(self.config.audio_pool_step, stride=self.config.audio_pool_step)
            self.audio_projection_layer = MultiModalProjector(in_dim=audio_output_dim, out_dim=self.embed_dim)
            self.audio_encoder_layer = -1

        # init tts module
        if self.config.init_tts:
            self.tts = self.init_tts_module()

        self.terminators = ["<|tts_eos|>", "<|im_end|>", "<|endoftext|>", "</s>"]

        think_str = ""
        if self.llm.config.__class__.__name__ == "Qwen3Config":
            think_str = "<think>\\n\\n</think>\\n\\n"
        if self.config.tts_config.use_speaker_embedding:
            self.default_tts_chat_template = (
                "{% for message in messages %}{{'<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n'}}{% endfor %}{% if add_generation_prompt %}{{ '<|im_start|>assistant\n"
                + think_str
                + "<|spk_bos|><|spk|><|spk_eos|><|tts_bos|>' }}{% endif %}"
            )
        else:
            self.default_tts_chat_template = (
                "{% for message in messages %}{{'<|im_start|>' + message['role'] + '\n' + message['content'] + '<|im_end|>' + '\n'}}{% endfor %}{% if add_generation_prompt %}{{ '<|im_start|>assistant\n"
                + think_str
                + "<|tts_bos|>' }}{% endif %}"
            )

        self.llm_past_key_values = None
        self.audio_past_key_values = None
        self.tts_last_turn_tokens = None
        self.new_user_msg = False

    def init_vision_module(self):
        if self.config._attn_implementation == "flash_attention_2":
            self.config.vision_config._attn_implementation = "flash_attention_2"
        else:
            self.config.vision_config._attn_implementation = "eager"
        model = SiglipVisionTransformer(self.config.vision_config)
        if self.config.drop_vision_last_layer:
            model.encoder.layers = model.encoder.layers[:-1]

        setattr(model, "embed_dim", model.embeddings.embed_dim)
        setattr(model, "patch_size", model.embeddings.patch_size)

        return model

    def init_resampler(self, embed_dim, vision_dim):
        return Resampler(
            num_queries=self.config.query_num,
            embed_dim=embed_dim,
            num_heads=embed_dim // 128,
            kv_dim=vision_dim,
            adaptive=True,
        )

    def init_audio_module(self):
        return MiniCPMWhisperEncoder(self.config.audio_config)

    def init_tts_module(self):
        return MiniCPMTTS(config=self.config.tts_config, audio_tokenizer=None)

    def init_tts(self, model_dir=None, code_dir=None):
        tts_config = self.config.tts_config
        audio_tokenizer_type = tts_config.audio_tokenizer_type

        if audio_tokenizer_type == "s3tokenizer":
            if tts_config.s3_stream_generate:
                audio_tokenizer = self._init_cosyvoice_stream(model_dir, code_dir)
            else:
                audio_tokenizer = self._init_cosyvoice(model_dir, code_dir)
        else:
            raise NotImplementedError(f"Unsupported audio tokenizer type: {audio_tokenizer_type}")

        self.tts.audio_tokenizer = audio_tokenizer
        logger.info(f"Audio tokenizer initialized: {audio_tokenizer_type}")
        return audio_tokenizer

    @staticmethod
    def _init_cosyvoice(model_dir, code_dir=None):
        import os
        import sys

        cosyvoice_path = code_dir
        matcha_path = os.path.join(cosyvoice_path, "third_party", "Matcha-TTS")

        if cosyvoice_path not in sys.path:
            sys.path.insert(0, cosyvoice_path)
        if os.path.exists(matcha_path) and matcha_path not in sys.path:
            sys.path.insert(0, matcha_path)

        try:
            from cosyvoice.cli.cosyvoice import CosyVoice2

            logger.info(f"Using CosyVoice2 from: {cosyvoice_path}")
        except ImportError:
            raise ImportError(f"Could not import CosyVoice2 from {cosyvoice_path}")

        cosyvoice = CosyVoice2(model_dir=model_dir, load_jit=False, load_trt=False, fp16=False)
        logger.info(f"CosyVoice2 initialized from: {model_dir}")
        return cosyvoice

    @staticmethod
    def _init_cosyvoice_stream(model_dir, code_dir=None):
        import os
        import sys

        cosyvoice_stream_path = code_dir
        matcha_path = os.path.join(cosyvoice_stream_path, "third_party", "Matcha-TTS")

        if cosyvoice_stream_path not in sys.path:
            sys.path.insert(0, cosyvoice_stream_path)
        if os.path.exists(matcha_path) and matcha_path not in sys.path:
            sys.path.insert(0, matcha_path)

        try:
            from cosyvoice.cli.cosyvoice import CosyVoice2 as CosyVoice2Stream

            logger.info(f"Using CosyVoice2 Stream from: {cosyvoice_stream_path}")
        except ImportError:
            raise ImportError("CosyVoice2 Stream not found")

        cosyvoice = CosyVoice2Stream(model_dir=model_dir, load_jit=False, load_trt=False, fp16=False)
        logger.info(f"CosyVoice2 (Stream) initialized from: {model_dir}")
        return cosyvoice

    def get_input_embeddings(self):
        return self.llm.get_input_embeddings()

    def set_input_embeddings(self, value):
        self.llm.embed_tokens = value

    def get_output_embeddings(self):
        return self.llm.lm_head

    def set_output_embeddings(self, new_embeddings):
        self.llm.lm_head = new_embeddings

    def set_decoder(self, decoder):
        self.llm = decoder

    def get_decoder(self):
        return self.llm

    def subsequent_chunk_mask(
        self,
        size: int,
        chunk_size: int,
        num_left_chunks: int = -1,
        device: torch.device = torch.device("cpu"),
        num_lookhead: int = 0,
    ) -> torch.Tensor:
        """Create mask for subsequent steps (size, size) with chunk size,
        this is for streaming encoder

        Args:
            size (int): size of mask
            chunk_size (int): size of chunk
            num_left_chunks (int): number of left chunks
                <0: use full chunk
                >=0: use num_left_chunks
            device (torch.device): "cpu" or "cuda" or torch.Tensor.device
            num_lookhead:

        Returns:
            torch.Tensor: mask

        Examples:
            >>> subsequent_chunk_mask(4, 2)
            [[1, 1, 0, 0],
            [1, 1, 0, 0],
            [1, 1, 1, 1],
            [1, 1, 1, 1]]
        """
        ret = torch.zeros(size, size, device=device, dtype=torch.bool)
        for i in range(size):
            if num_left_chunks < 0:
                start = 0
            else:
                start = max((i // chunk_size - num_left_chunks) * chunk_size, 0)
            ending = min((i // chunk_size + 1) * chunk_size + num_lookhead, size)
            ret[i, start:ending] = True
        return ret

    def _get_feat_extract_output_lengths(self, input_lengths: torch.LongTensor):
        """
        Computes the output length of the convolutional layers and the output length of the audio encoder
        """
        input_lengths_after_cnn = (input_lengths - 1) // 2 + 1
        input_lengths_after_pooling = (
            input_lengths_after_cnn - self.config.audio_pool_step
        ) // self.config.audio_pool_step + 1
        input_lengths_after_pooling = input_lengths_after_pooling.to(dtype=torch.int32)

        return input_lengths_after_cnn, input_lengths_after_pooling

    def get_vllm_embedding(self, data):
        if "vision_hidden_states" not in data:
            dtype = self.llm.model.embed_tokens.weight.dtype
            device = self.llm.model.embed_tokens.weight.device
            tgt_sizes = data["tgt_sizes"]
            pixel_values_list = data["pixel_values"]
            vision_hidden_states = []
            all_pixel_values = []
            img_cnt = []
            for pixel_values in pixel_values_list:
                img_cnt.append(len(pixel_values))
                all_pixel_values.extend([i.flatten(end_dim=1).permute(1, 0) for i in pixel_values])

            # exist image
            if all_pixel_values:
                tgt_sizes = [tgt_size for tgt_size in tgt_sizes if isinstance(tgt_size, torch.Tensor)]
                tgt_sizes = torch.vstack(tgt_sizes).type(torch.int32)

                max_patches = torch.max(tgt_sizes[:, 0] * tgt_sizes[:, 1])

                all_pixel_values = torch.nn.utils.rnn.pad_sequence(
                    all_pixel_values, batch_first=True, padding_value=0.0
                )
                B, L, _ = all_pixel_values.shape
                all_pixel_values = all_pixel_values.permute(0, 2, 1).reshape(B, 3, -1, L)

                patch_attn_mask = torch.zeros((B, 1, max_patches), dtype=torch.bool, device=device)
                for i in range(B):
                    patch_attn_mask[i, 0, : tgt_sizes[i][0] * tgt_sizes[i][1]] = True

                vision_batch_size = self.config.vision_batch_size
                all_pixel_values = all_pixel_values.type(dtype)
                if B > vision_batch_size:
                    hs = []
                    for i in range(0, B, vision_batch_size):
                        start_idx = i
                        end_idx = i + vision_batch_size
                        tmp_hs = self.vpm(
                            all_pixel_values[start_idx:end_idx],
                            patch_attention_mask=patch_attn_mask[start_idx:end_idx],
                            tgt_sizes=tgt_sizes[start_idx:end_idx],
                        ).last_hidden_state
                        hs.append(tmp_hs)
                    vision_embedding = torch.cat(hs, dim=0)
                else:
                    vision_embedding = self.vpm(
                        all_pixel_values,
                        patch_attention_mask=patch_attn_mask,
                        tgt_sizes=tgt_sizes,
                    ).last_hidden_state
                vision_embedding = self.resampler(vision_embedding, tgt_sizes)

                start = 0
                for pixel_values in pixel_values_list:
                    img_cnt = len(pixel_values)
                    if img_cnt > 0:
                        vision_hidden_states.append(vision_embedding[start : start + img_cnt])
                        start += img_cnt
                    else:
                        vision_hidden_states.append([])
            else:  # no image
                if self.training:
                    dummy_image = torch.zeros((1, 3, 224, 224), device=device, dtype=dtype)
                    tgt_sizes = torch.Tensor(
                        [
                            [
                                (224 // self.config.patch_size),
                                math.ceil(224 / self.config.patch_size),
                            ]
                        ]
                    ).type(torch.int32)
                    dummy_feature = self.resampler(self.vpm(dummy_image).last_hidden_state, tgt_sizes)
                else:
                    dummy_feature = []
                for _ in range(len(pixel_values_list)):
                    vision_hidden_states.append(dummy_feature)

        else:
            vision_hidden_states = data["vision_hidden_states"]

        if hasattr(self.llm.config, "scale_emb"):
            vllm_embedding = self.llm.model.embed_tokens(data["input_ids"]) * self.llm.config.scale_emb
        else:
            vllm_embedding = self.llm.model.embed_tokens(data["input_ids"])

        vision_hidden_states = [
            i.type(vllm_embedding.dtype) if isinstance(i, torch.Tensor) else i for i in vision_hidden_states
        ]

        bs = len(data["input_ids"])
        for i in range(bs):
            cur_vs_hs = vision_hidden_states[i]
            if len(cur_vs_hs) > 0:
                cur_vllm_emb = vllm_embedding[i]
                cur_image_bound = data["image_bound"][i]
                if len(cur_image_bound) > 0:
                    image_indices = torch.stack(
                        [torch.arange(r[0], r[1], dtype=torch.long) for r in cur_image_bound]
                    ).to(vllm_embedding.device)

                    cur_vllm_emb.scatter_(
                        0,
                        image_indices.view(-1, 1).repeat(1, cur_vllm_emb.shape[-1]),
                        cur_vs_hs.view(-1, cur_vs_hs.shape[-1]),
                    )
                elif self.training:
                    cur_vllm_emb += cur_vs_hs[0].mean() * 0

        return vllm_embedding, vision_hidden_states

    def get_audio_embedding_streaming(self, data):
        dtype = self.apm.embed_positions.weight.dtype
        device = self.apm.embed_positions.weight.device

        wavforms = data.get("audio_features", [])  # (bs, 80, frames) or [], 多条数据多个音频是提前 padding 好
        audio_feature_lens_raw = data.get("audio_feature_lens", [])  # list, [[x1, x2], [y1], [z1]]

        # exist audio
        if len(wavforms) > 0:
            audio_feature_lens = torch.hstack(audio_feature_lens_raw)
            batch_size, _, max_mel_seq_len = wavforms.shape
            assert batch_size == 1
            max_seq_len = (
                max_mel_seq_len - 1
            ) // 2 + 1  # 原本代码是(max_mel_seq_len - 2) // 2 + 1 如果输入长度是奇数的话就会差1

            # whisper 的 past_key_values 管理 (core)
            if self.audio_past_key_values is not None:
                cache_length = self.audio_past_key_values[0][0].shape[2]
                apm_max_len = self.apm.embed_positions.weight.shape[0]
                if cache_length + max_seq_len >= apm_max_len:
                    logger.warning(
                        f"audio_past_key_values length {cache_length + max_seq_len} exceed {apm_max_len}, reset."
                    )
                    self.audio_past_key_values = None

            audio_outputs = self.apm(wavforms, past_key_values=self.audio_past_key_values, use_cache=True)
            # audio_outputs.last_hidden_state 是新鲜的（这波audio）的hidden 就要这些做feature！
            audio_states = audio_outputs.last_hidden_state  # [:, :audio_feat_lengths, :]
            self.audio_past_key_values = audio_outputs.past_key_values

            audio_embeds = self.audio_projection_layer(audio_states)

            audio_embeds = audio_embeds.transpose(1, 2)
            audio_embeds = self.audio_avg_pooler(audio_embeds)
            audio_embeds = audio_embeds.transpose(1, 2)

            _, feature_lens_after_pooling = self._get_feat_extract_output_lengths(audio_feature_lens)

            num_audio_tokens = feature_lens_after_pooling

            final_audio_embeds = []
            idx = 0
            for i in range(len(audio_feature_lens_raw)):
                target_audio_embeds = []
                for _ in range(len(audio_feature_lens_raw[i])):
                    target_audio_embeds.append(audio_embeds[idx, : num_audio_tokens[idx], :])
                    idx += 1
                final_audio_embeds.append(target_audio_embeds)
            return final_audio_embeds
        else:
            return []

    def get_audio_embedding(self, data, chunk_length=-1, dummy=True):
        dtype = self.apm.embed_positions.weight.dtype
        device = self.apm.embed_positions.weight.device

        wavforms = data.get("audio_features", [])  # (bs, 80, frames) or [], 多条数据多个音频是提前 padding 好
        audio_feature_lens_raw = data.get("audio_feature_lens", [])  # list, [[x1, x2], [y1], [z1]]

        # exist audio
        if len(wavforms) > 0:
            audio_feature_lens = torch.hstack(audio_feature_lens_raw)
            batch_size, _, max_mel_seq_len = wavforms.shape
            max_seq_len = (max_mel_seq_len - 1) // 2 + 1

            # Create a sequence tensor of shape (batch_size, max_seq_len)
            seq_range = (
                torch.arange(
                    0,
                    max_seq_len,
                    dtype=audio_feature_lens.dtype,
                    device=audio_feature_lens.device,
                )
                .unsqueeze(0)
                .expand(batch_size, max_seq_len)
            )
            lengths_expand = audio_feature_lens.unsqueeze(1).expand(batch_size, max_seq_len)
            # Create mask
            padding_mask = seq_range >= lengths_expand  # 1 for padded values

            audio_attention_mask_ = padding_mask.view(batch_size, 1, 1, max_seq_len).expand(
                batch_size, 1, max_seq_len, max_seq_len
            )
            audio_attention_mask = audio_attention_mask_.to(
                dtype=self.apm.conv1.weight.dtype, device=self.apm.conv1.weight.device
            )

            if chunk_length > 0:
                chunk_num_frame = int(chunk_length * 50)
                chunk_mask = self.subsequent_chunk_mask(
                    size=max_seq_len,
                    chunk_size=chunk_num_frame,
                    num_left_chunks=-1,
                    device=audio_attention_mask_.device,
                )
                audio_attention_mask_ = torch.logical_or(audio_attention_mask_, torch.logical_not(chunk_mask))

            audio_attention_mask[audio_attention_mask_] = float("-inf")
            audio_states = self.apm(
                wavforms, output_hidden_states=True, attention_mask=audio_attention_mask
            ).hidden_states[self.audio_encoder_layer]
            audio_embeds = self.audio_projection_layer(audio_states)

            audio_embeds = audio_embeds.transpose(1, 2)
            audio_embeds = self.audio_avg_pooler(audio_embeds)
            audio_embeds = audio_embeds.transpose(1, 2)

            _, feature_lens_after_pooling = self._get_feat_extract_output_lengths(audio_feature_lens)

            num_audio_tokens = feature_lens_after_pooling

            final_audio_embeds = []
            idx = 0
            for i in range(len(audio_feature_lens_raw)):
                target_audio_embeds = []
                for _ in range(len(audio_feature_lens_raw[i])):
                    target_audio_embeds.append(audio_embeds[idx, : num_audio_tokens[idx], :])
                    idx += 1
                final_audio_embeds.append(target_audio_embeds)
            return final_audio_embeds
        elif self.training and dummy:
            dummy_wavs = torch.zeros((1, 80, 100), device=device, dtype=dtype)
            audio_states = self.apm(dummy_wavs, output_hidden_states=True).hidden_states[self.audio_encoder_layer]

            audio_embeds = self.audio_projection_layer(audio_states)

            audio_embeds = audio_embeds.transpose(1, 2)
            audio_embeds = self.audio_avg_pooler(audio_embeds)
            audio_embeds = audio_embeds.transpose(1, 2)
            return [audio_embeds]

        else:
            return []

    def get_omni_embedding(self, data, input_embeddings, chunk_length=-1, stream_input=False):
        if stream_input:
            audio_embeddings = self.get_audio_embedding_streaming(data)
        else:
            audio_embeddings = self.get_audio_embedding(data, chunk_length)

        bs = len(input_embeddings)
        if len(data.get("audio_features", [])) > 0:
            assert len(audio_embeddings) == len(input_embeddings)

            if len(audio_embeddings) > 0:
                audio_bounds = data["audio_bounds"]

                if self.config.stream_input:
                    assert bs == 1, "audio stream_input mode only support batch size 1"
                    for i in range(bs):
                        audio_embs = torch.cat(audio_embeddings[i], dim=0).to(
                            device=input_embeddings.device, dtype=input_embeddings.dtype
                        )
                        audio_start_pos = 0
                        for bound in audio_bounds[i]:
                            audio_len = bound[1] - bound[0]
                            input_embeddings[i, bound[0] : bound[1]] = audio_embs[
                                audio_start_pos : audio_start_pos + audio_len, :
                            ]
                            audio_start_pos += audio_len
                else:
                    for i in range(bs):
                        audio_embs = audio_embeddings[i]
                        bounds = audio_bounds[i]
                        for embs, bound in zip(audio_embs, bounds):
                            audio_indices = torch.arange(bound[0], bound[1], dtype=torch.long).to(
                                input_embeddings.device
                            )

                            if embs.shape[0] != len(audio_indices):
                                logger.error(f"Sample {i}:")
                                logger.error(f"  Bounds: {bound}, Indices Length: {len(audio_indices)}")
                                logger.error(f"  Embeddings Shape: {embs.shape}")
                                logger.error(
                                    f"  Input Embedding Shape at Indices: {input_embeddings[i, audio_indices].shape}"
                                )
                                raise ValueError(
                                    f"Shape mismatch: Trying to assign embeddings of shape {embs.shape} "
                                    f"to input indices of length {len(audio_indices)}"
                                )
                            input_embeddings[i, audio_indices] = embs.to(input_embeddings.dtype)
        elif self.training:
            for i in range(bs):
                # dummy audio_embedings
                input_embeddings += audio_embeddings[0].mean() * 0

        return input_embeddings

    def forward(self, data, **kwargs):
        vllm_embedding, vision_hidden_states = self.get_vllm_embedding(data)
        vllm_embedding = self.get_omni_embedding(
            data,
            input_embeddings=vllm_embedding,
            chunk_length=self.config.audio_chunk_length,
        )

        position_ids = data["position_ids"]
        if position_ids.dtype != torch.int64:
            position_ids = position_ids.long()

        return self.llm(
            input_ids=None,
            position_ids=position_ids,
            inputs_embeds=vllm_embedding,
            **kwargs,
        )

    def _decode(self, inputs_embeds, tokenizer, attention_mask, **kwargs):
        terminators = [tokenizer.convert_tokens_to_ids(i) for i in self.terminators]
        outputs = self.llm.generate(
            inputs_embeds=inputs_embeds,
            pad_token_id=0,
            eos_token_id=terminators,
            attention_mask=attention_mask,
            output_hidden_states=True,
            return_dict_in_generate=True,
            **kwargs,
        )
        return outputs

    def _decode_text(self, result_ids, tokenizer):
        terminators = [tokenizer.convert_tokens_to_ids(i) for i in self.terminators]
        result_text = []
        for result in result_ids:
            result = result[result != 0]
            if result[0] == tokenizer.bos_id:
                result = result[1:]
            if result[-1] in terminators:
                result = result[:-1]
            result_text.append(tokenizer.decode(result).strip())
        return result_text

    @torch.inference_mode()
    def generate(
        self,
        input_ids=None,
        pixel_values=None,
        tgt_sizes=None,
        audio_features=None,
        audio_feature_lens=None,
        image_bound=None,
        audio_bounds=None,
        spk_bounds=None,
        attention_mask=None,
        tokenizer=None,
        vision_hidden_states=None,
        stream=False,
        **kwargs,
    ):
        assert input_ids is not None
        assert len(input_ids) == len(pixel_values)

        model_inputs = {
            "input_ids": input_ids,
            "audio_features": audio_features,
            "audio_feature_lens": audio_feature_lens,
            "image_bound": image_bound,
            "audio_bounds": audio_bounds,
            "spk_bounds": spk_bounds,
        }

        if vision_hidden_states is None:
            model_inputs["pixel_values"] = pixel_values
            model_inputs["tgt_sizes"] = tgt_sizes
        else:
            model_inputs["vision_hidden_states"] = vision_hidden_states

        model_output = {}
        with torch.inference_mode():
            model_inputs["inputs_embeds"], vision_hidden_states = self.get_vllm_embedding(model_inputs)
            model_inputs["inputs_embeds"] = self.get_omni_embedding(
                model_inputs,
                input_embeddings=model_inputs["inputs_embeds"],
                chunk_length=self.config.audio_chunk_length,
            )

            outputs = self._decode(model_inputs["inputs_embeds"], tokenizer, attention_mask, **kwargs)

            result = self._decode_text(outputs.sequences, tokenizer)

        return result, outputs

    def _build_streaming_mask(self, tts_tokens_len):
        tts_sequence_full_length = (
            1 + self.tts.num_spk_embs * self.tts.use_speaker_embedding + self.tts.streaming_text_reserved_len + 1
        )
        streaming_attention_mask = torch.zeros(tts_sequence_full_length, dtype=torch.int8)
        streaming_attention_mask[0 : 1 + 1 + tts_tokens_len + 1] = 1
        streaming_attention_mask[-1] = 1
        return streaming_attention_mask

    def _generate_mel_spec(self, inputs, outputs, text, output_chunk_size=25, tts_max_new_tokens=2048):
        spk_embeds = self._get_last_spk_embeds(inputs, outputs)

        text = text.split("<|tts_bos|>")[-1]
        gen_text = text.split("<|tts_eos|>")[0]
        tts_text, tts_token_lens = self.prepare_tts_text(gen_text)
        tts_inputs = self.tts_processor.text_tokenizer.encode(tts_text, add_special_tokens=False)
        tts_input_ids = torch.Tensor(tts_inputs).unsqueeze(0).to(self.device, dtype=torch.long)
        streaming_tts_text_mask = self._build_streaming_mask(tts_token_lens).to(device=self.tts.device)

        logits_warpers, logits_processors = gen_logits(
            num_code=626,
            top_P=self.tts.top_p,
            top_K=self.tts.top_k,
            repetition_penalty=self.tts.repetition_penalty,
        )

        condition_length = (
            1 + self.tts.use_speaker_embedding * self.tts.num_spk_embs + self.tts.streaming_text_reserved_len + 1
        )

        dtype = self.tts.emb_text.weight.dtype
        emb = torch.zeros(1, condition_length, self.tts.num_vq, dtype=dtype, device=self.tts.device)
        past_key_values = [
            (
                torch.zeros(
                    1,
                    self.tts.config.num_attention_heads,
                    condition_length - 1,
                    self.tts.config.hidden_size // self.tts.config.num_attention_heads,
                    dtype=emb.dtype,
                    device=self.tts.device,
                ),
                torch.zeros(
                    1,
                    self.tts.config.num_attention_heads,
                    condition_length - 1,
                    self.tts.config.hidden_size // self.tts.config.num_attention_heads,
                    dtype=emb.dtype,
                    device=self.tts.device,
                ),
            )
            for _ in range(self.tts.config.num_hidden_layers)
        ]

        audio_input_ids = torch.zeros(
            1,
            condition_length,
            self.tts.num_vq,
            dtype=torch.long,
            device=self.tts.device,
        )

        eos_lab = False
        for chunk_idx in range(math.ceil(emb.shape[1] / self.tts.streaming_text_chunk_size)):
            if chunk_idx == 0:
                begin = chunk_idx * self.tts.streaming_text_chunk_size + 0
                end = (
                    (chunk_idx + 1) * self.tts.streaming_text_chunk_size
                    + 1
                    + self.tts.use_speaker_embedding * self.tts.num_spk_embs
                )
            else:
                begin = (
                    chunk_idx * self.tts.streaming_text_chunk_size
                    + 1
                    + self.tts.use_speaker_embedding * self.tts.num_spk_embs
                )
                end = min(
                    (chunk_idx + 1) * self.tts.streaming_text_chunk_size
                    + 1
                    + self.tts.use_speaker_embedding * self.tts.num_spk_embs,
                    condition_length - 1,
                )

            if end - begin > 0:
                text_input_ids = tts_input_ids[:, begin:end]
                position_ids = torch.arange(begin, end, dtype=torch.long, device=self.tts.device).unsqueeze(0)

                if begin == 0:
                    past_key_values = self.tts.prefill_text(
                        input_ids=text_input_ids,
                        position_ids=position_ids,
                        past_key_values=past_key_values,
                        lm_spk_emb_last_hidden_states=spk_embeds,
                    )
                else:
                    past_key_values = self.tts.prefill_text(
                        input_ids=text_input_ids,
                        position_ids=position_ids,
                        past_key_values=past_key_values,
                    )

            outputs = self.tts.generate(
                input_ids=audio_input_ids,
                past_key_values=past_key_values,
                streaming_tts_text_mask=streaming_tts_text_mask,
                max_new_token=output_chunk_size,
                force_no_stop=self.force_no_stop,
                temperature=torch.tensor([0.1, 0.3, 0.1, 0.3], dtype=torch.float, device=self.tts.device),
                eos_token=torch.tensor([625], dtype=torch.long, device=self.tts.device),
                logits_warpers=logits_warpers,
                logits_processors=logits_processors,
            )
            audio_input_ids = outputs.audio_input_ids
            past_key_values = outputs.past_key_values

            if outputs.finished:
                logger.debug("Generation finished.")
                eos_lab = True
                break

        if not eos_lab:
            logger.debug("eos_lab False, Generation continue.")
            while True:
                outputs = self.tts.generate(
                    input_ids=audio_input_ids,
                    past_key_values=past_key_values,
                    streaming_tts_text_mask=streaming_tts_text_mask,
                    max_new_token=output_chunk_size,
                    force_no_stop=self.force_no_stop,
                    temperature=torch.tensor([0.1, 0.3, 0.1, 0.3], dtype=torch.float, device=self.tts.device),
                    eos_token=torch.tensor([625], dtype=torch.long, device=self.tts.device),
                    logits_warpers=logits_warpers,
                    logits_processors=logits_processors,
                )

                audio_input_ids = outputs.audio_input_ids
                past_key_values = outputs.past_key_values

                if outputs.finished:
                    logger.debug("Generation finished.")
                    break
                if outputs.new_ids.shape[1] > tts_max_new_tokens:
                    logger.debug(f"Generation length > {tts_max_new_tokens}, stopped.")
                    break

    @torch.inference_mode()
    def chat(
        self,
        image,
        msgs,
        tokenizer,
        processor=None,
        vision_hidden_states=None,
        max_new_tokens=4096,
        min_new_tokens=0,
        sampling=True,
        max_inp_length=8192,
        stream=False,
        stream_input=False,
        max_slice_nums=None,
        use_image_id=None,
        use_tts=False,
        output_audio_path=None,
        output_tts_inputs_embeds_path=None,
        # add
        audio_mode=False,
        omni_mode=False,
        speaker_embedding_only=False,
        teacher_forcing=False,
        teacher_forcing_text="",
        return_prompt=False,
        tts_proj_layer=-1,
        streaming_generate=False,
        tts_sampling_params: TTSSamplingParams = TTSSamplingParams(),
        prompt_audio_24khz_path=None,
        **kwargs,
    ):
        batched = isinstance(msgs[0], list)
        msgs_list = msgs
        images_list = image

        if not batched:
            images_list, msgs_list = [images_list], [msgs_list]
        else:
            assert images_list is None, "Please integrate image to msgs when using batch inference."
            images_list = [None] * len(msgs_list)
        assert len(images_list) == len(msgs_list), "The batch dim of images_list and msgs_list should be the same."

        if processor is None:
            if self.processor is None:
                raise ValueError("model.processor is not set")
            processor = self.processor

        prompts_lists = []
        input_images_list = []
        input_audios_list = []
        audio_parts_list = []

        for image, msgs in zip(images_list, msgs_list):
            if isinstance(msgs, str):
                msgs = json.loads(msgs)
            copy_msgs = deepcopy(msgs)

            assert len(msgs) > 0, "msgs is empty"
            assert sampling or not stream, "if use stream mode, make sure sampling=True"

            if image is not None and isinstance(copy_msgs[0]["content"], str):
                copy_msgs[0]["content"] = [image, copy_msgs[0]["content"]]

            images = []
            audios = []
            audio_parts = []
            aid = 0
            for i, msg in enumerate(copy_msgs):
                aid += 1  # change aid  when new msg
                role = msg["role"]
                content = msg["content"]
                assert role in ["system", "user", "assistant"]
                if i == 0:
                    assert role in ["user", "system"], "The role of first msg should be user"
                if isinstance(content, str):
                    content = [content]
                cur_msgs = []
                for c in content:
                    if isinstance(c, Image.Image):
                        images.append(c)
                        cur_msgs.append("<image>./</image>")
                        aid += 1  # change aid when discontinuous audio
                    elif isinstance(c, np.ndarray):  # audio
                        audios.append(c)
                        audio_parts.append(aid)
                        cur_msgs.append("<audio>./</audio>")
                    elif isinstance(c, str):
                        cur_msgs.append(c)
                        aid += 1  # change aid when discontinuous audio

                if audio_mode:
                    msg["content"] = "\n".join(cur_msgs)
                elif omni_mode:
                    msg["content"] = "".join(cur_msgs)
                elif stream_input:
                    msg["content"] = "".join(cur_msgs)
                else:
                    msg["content"] = "\n".join(cur_msgs)

            # 这里如果是teacher forcing，那么不需要add_generation_prompt了, i.e. 不需要[spk part]<|tts_bos|>
            # 如果不是，需要add_generation_prompt i.e. [spk part]<|tts_bos|>
            prompts_lists.append(
                processor.tokenizer.apply_chat_template(
                    copy_msgs,
                    tokenize=False,
                    add_generation_prompt=False if teacher_forcing else True,
                    chat_template=self.default_tts_chat_template if use_tts else None,
                )
            )
            input_images_list.append(images)
            input_audios_list.append(audios)
            audio_parts_list.append(audio_parts)

        try:
            audio_prompt = input_audios_list[0][0]
        except:
            raise ValueError("no audio prompt found in data")

        inputs = processor(
            prompts_lists,
            input_images_list,
            input_audios_list,
            audio_parts_list,
            max_slice_nums=max_slice_nums,
            use_image_id=use_image_id,
            stream_input=stream_input,
            return_tensors="pt",
            max_length=max_inp_length,
        ).to(self.device)

        if sampling:
            generation_config = {
                "top_p": 0.8,
                "top_k": 20,
                "temperature": 0.7,
                "do_sample": False,
                "repetition_penalty": 1.05,
            }
        else:
            generation_config = {
                "num_beams": 3,
                "repetition_penalty": 1.2,
            }

        if min_new_tokens > 0:
            generation_config["min_new_tokens"] = min_new_tokens

        generation_config.update((k, kwargs[k]) for k in generation_config.keys() & kwargs.keys())

        inputs.pop("image_sizes")

        # teacher_forcing = True => 给定文本来生成语音
        with torch.inference_mode():
            res, outputs = self.generate(
                **inputs,
                tokenizer=tokenizer,
                max_new_tokens=1 if teacher_forcing else max_new_tokens,
                vision_hidden_states=vision_hidden_states,
                stream=stream,
                **generation_config,
            )

        # 得到 spk bound 和 tts bound 的位置
        spk_bos_token = tokenizer.convert_tokens_to_ids("<|spk_bos|>")
        spk_eos_token = tokenizer.convert_tokens_to_ids("<|spk_eos|>")
        tts_bos_token = tokenizer.convert_tokens_to_ids("<|tts_bos|>")
        tts_eos_token = tokenizer.convert_tokens_to_ids("<|tts_eos|>")

        # Combine input_ids and generated sequences to get complete sequence
        input_ids = inputs["input_ids"][0]
        generated_ids = outputs.sequences[0]
        # Combine by concatenating input_ids with the new tokens from generated sequence
        full_sequence = torch.cat([input_ids, generated_ids])
        # Update the sequences in outputs
        full_sequences = full_sequence.unsqueeze(0)

        outputs["full_sequences"] = full_sequences

        # Find all occurrences and get the last one
        spk_bos_indices = []
        spk_eos_indices = []
        for i, x in enumerate(full_sequences[0]):
            if x == spk_bos_token:
                spk_bos_indices.append(i + 1)  # spk_bos + 1 才是第一个spk的位置，这样方便直接给tts去slice hidden states
            elif x == spk_eos_token:
                # it can't be the last token.
                if i == len(full_sequences[0]) - 1:
                    continue
                spk_eos_indices.append(i)

        spk_bos_idx = spk_bos_indices[-1] if spk_bos_indices else -1
        spk_eos_idx = spk_eos_indices[-1] if spk_eos_indices else -1

        logger.debug(f"spk_bos_idx: {spk_bos_idx}, spk_eos_idx: {spk_eos_idx}")

        # 找出<|tts_bos|>和<|tts_eos|>
        tts_bos_indices = []
        tts_eos_indices = []
        for i, x in enumerate(full_sequences[0]):
            if x == tts_bos_token:
                tts_bos_indices.append(i + 1)  # tts_bos + 1 才是第一个tts的位置，这样方便直接给tts去slice hidden states
            elif x == tts_eos_token:
                if teacher_forcing and i==len(full_sequences[0]) -  1:
                    continue
                # it can't be the last token.
                # if i == len(full_sequences[0]) - 1:
                #     continue
                tts_eos_indices.append(i)

        tts_bos_idx = tts_bos_indices[-1] if tts_bos_indices else -1
        tts_eos_idx = tts_eos_indices[-1] if tts_eos_indices else -1

        spk_bound = (spk_bos_idx, spk_eos_idx)
        tts_bound = (tts_bos_idx, tts_eos_idx)

        # logger.debug("extracted spk_bound", spk_bound)
        # logger.debug("extracted tts_bound", tts_bound)
        logger.debug("extracted spk_bound %s", spk_bound)
        logger.debug("extracted tts_bound %s", tts_bound)

        answer = res[0]

        if use_tts and output_audio_path:
            try:
                generated_waveform = self._generate_speech_non_streaming(
                    inputs,
                    outputs,
                    spk_bound,
                    tts_bound,
                    answer,
                    tts_proj_layer,
                    processor.tokenizer,
                    audio_prompt,
                    streaming_generate=streaming_generate,
                    output_tts_inputs_embeds_path=output_tts_inputs_embeds_path,
                    tts_sampling_params=tts_sampling_params,
                )
                if isinstance(generated_waveform, torch.Tensor):
                    sf.write(
                        output_audio_path,
                        generated_waveform.cpu().numpy(),
                        samplerate=24000,
                    )
                elif isinstance(generated_waveform, np.ndarray):
                    sf.write(output_audio_path, generated_waveform, samplerate=24000)
                logger.debug(f"audio saved to {output_audio_path}")
            except:
                import traceback
                traceback.print_exc()

        if return_prompt:
            return answer, prompts_lists[0]
        else:
            return answer

    @torch.inference_mode()
    def _generate_speech_non_streaming(
        self,
        inputs,
        outputs,
        spk_bound,
        tts_bound,
        text,
        tts_proj_layer,
        tokenizer,
        audio_prompt,
        streaming_generate=False,
        output_tts_inputs_embeds_path=None,
        tts_sampling_params: TTSSamplingParams = TTSSamplingParams(),
    ):
        last_hidden_states = [hs[tts_proj_layer] for hs in outputs.hidden_states]
        last_hidden_states = torch.vstack([i[0] for i in last_hidden_states])

        if self.config.tts_config.use_speaker_embedding:
            spk_embeds = last_hidden_states[spk_bound[0] : spk_bound[1]]
            spk_embeds = self.tts.projector_spk(spk_embeds)
            spk_embeds = F.normalize(spk_embeds, p=2, dim=-1)
        else:
            spk_embeds = (
                torch.ones([0, self.tts.config.hidden_size]).to(last_hidden_states.device).to(last_hidden_states.dtype)
            )

        if self.tts.condition_type == "llm_hidden":
            tts_embeds = last_hidden_states[tts_bound[0] : tts_bound[1]]
            tts_embeds = self.tts.projector_semantic(tts_embeds)
            tts_embeds = F.normalize(tts_embeds, p=2, dim=-1)
        elif self.tts.condition_type == "tts_token":
            raw_text = self.tokenizer.decode(outputs["full_sequences"][0][tts_bound[0] : tts_bound[1]])

            raw_text = raw_text.replace("<|im_end|>", "").replace("<|tts_eos|>", "").replace("<|tts_bos|>", "")

            tts_tokens = self.tts_tokenizer.encode(raw_text, add_special_tokens=False)
            dev = self.tts.emb_text.weight.device
            tts_tokens = torch.tensor(tts_tokens, device=dev, dtype=torch.long)
            tts_embeds = self.tts.emb_text(tts_tokens)
        elif self.tts.condition_type == "tts_token_streaming":
            raw_text = self.tokenizer.decode(outputs["full_sequences"][0][tts_bound[0] : tts_bound[1]])

            raw_text = raw_text.replace("<|im_end|>", "").replace("<|tts_eos|>", "").replace("<|tts_bos|>", "")

            tts_tokens = self.tts_tokenizer.encode(raw_text, add_special_tokens=False)
            tts_tokens_valid_length = len(tts_tokens)  # 有效长度
            assert tts_tokens_valid_length <= 300, "tts_tokens_valid_length should be less than 300"
            pad_length = 300 - tts_tokens_valid_length  # 补齐长度

            raw_text += "[Etts]" + "[PAD]" * (pad_length - 1)

            raw_text_with_streaming_template = f"[Stts][spk_emb]{raw_text}[Ptts]"

            tts_tokens = self.tts_tokenizer.encode(raw_text_with_streaming_template, add_special_tokens=False)
            dev = self.tts.emb_text.weight.device
            tts_tokens = torch.tensor(tts_tokens, device=dev, dtype=torch.long)
            tts_embeds = self.tts.emb_text(tts_tokens)
        elif self.tts.condition_type == "llm_token":
            llm_tokens = outputs["full_sequences"][0][tts_bound[0] : tts_bound[1]]
            dev = self.tts.emb_text.weight.device
            llm_tokens = torch.tensor(llm_tokens, device=dev, dtype=torch.long)
            llm_embeds = self.tts.emb_text(llm_tokens)  # make sure emb_text is compatible with llm vocab size
            tts_embeds = llm_embeds
        elif self.tts.condition_type == "hidden_text_interleave":
            llm_tokens = outputs["full_sequences"][0][tts_bound[0] : tts_bound[1]]
            dev = self.tts.emb_text.weight.device
            llm_tokens = torch.tensor(llm_tokens, device=dev, dtype=torch.long)
            llm_embeds = self.tts.emb_text(llm_tokens)  # make sure emb_text is compatible with llm vocab size

            hidden_embeds = last_hidden_states[tts_bound[0] : tts_bound[1]]
            hidden_embeds = self.tts.projector_semantic(hidden_embeds)
            # hidden_embeds = F.normalize(hidden_embeds, p=2, dim=-1)

            cat_condition = torch.stack([llm_embeds, hidden_embeds], dim=0)  # [2, seq_len, gpt_hidden_dim]
            cat_condition = cat_condition.permute(1, 0, 2)
            interleaved_condition = cat_condition.reshape(cat_condition.shape[0] * 2, -1)
            print("tokens & hidden interleaved", interleaved_condition.shape)
            # 每 10 个分成一个chunk
            if self.tts.interleaved:
                tts_embeds = []
                cond_length = interleaved_condition.shape[0]
                for i in range(0, cond_length, 20):
                    tts_embeds.append(interleaved_condition[i : i + 20])
            else:
                tts_embeds = interleaved_condition
        elif self.tts.condition_type == "hidden_text_merge":
            llm_tokens = outputs["full_sequences"][0][tts_bound[0] : tts_bound[1]]
            dev = self.tts.emb_text.weight.device
            llm_tokens = torch.tensor(llm_tokens, device=dev, dtype=torch.long)
            llm_embeds = self.tts.emb_text(llm_tokens)  # make sure emb_text is compatible with llm vocab size

            hidden_embeds = last_hidden_states[tts_bound[0] : tts_bound[1]]
            hidden_embeds = self.tts.projector_semantic(hidden_embeds)

            if self.tts.config.normalize_projected_hidden:
                hidden_embeds = F.normalize(hidden_embeds, p=2, dim=-1)

            print("Shh2000", llm_embeds.shape, hidden_embeds.shape)
            if llm_embeds.shape[0] == hidden_embeds.shape[0] + 1:
                llm_embeds = llm_embeds[:-1]

            tts_embeds = llm_embeds + hidden_embeds
            if self.tts.interleaved:
                chunks = []
                cond_length = tts_embeds.shape[0]
                for i in range(0, cond_length, 10):
                    chunks.append(tts_embeds[i : i + 10])
                tts_embeds = chunks

        elif self.tts.condition_type == "llm_hidden_and_llm_embed_addition":
            raise NotImplementedError
        else:
            raise NotImplementedError

        audio_bos = [self.tts.audio_bos_token_id]
        dev = self.tts.emb_text.weight.device
        audio_bos = torch.tensor(audio_bos, device=dev, dtype=torch.long)

        audio_bos_embeds = self.tts.emb_text(audio_bos)

        if self.tts.interleaved:
            text_eos_embed = self.tts.emb_text(
                torch.tensor(
                    [self.tts.config.text_eos_token_id],
                    device=self.tts.emb_text.weight.device,
                    dtype=torch.long,
                )
            )
            tts_embeds[-1] = torch.cat([tts_embeds[-1], text_eos_embed], dim=0)
            for i in range(len(tts_embeds)):
                tts_embeds[i] = torch.cat([tts_embeds[i], audio_bos_embeds], dim=0).unsqueeze(0)
            outputs = self.tts.interleaved_generate(
                spk_embeds=spk_embeds,
                conditions=tts_embeds,
                temperature=0.8,
                repetition_penalty=1.05,
                eos_token=torch.tensor(
                    [self.tts.config.num_audio_tokens - 1],
                    dtype=torch.long,
                    device=self.tts.device,
                ),
            )
        else:

            if self.tts.condition_type == "tts_token":
                inputs_embeds = torch.cat([spk_embeds, tts_embeds, audio_bos_embeds], dim=0).unsqueeze(0)
            elif self.tts.condition_type == "tts_token_streaming":
                tts_embeds[1] = spk_embeds.squeeze(0)  # apply speaker embedding
                inputs_embeds = tts_embeds.unsqueeze(0)
            else:  # modern case
                inputs_embeds = torch.cat([spk_embeds, tts_embeds, audio_bos_embeds], dim=0).unsqueeze(0)

            # save inputs_embeds to file
            if output_tts_inputs_embeds_path:
                torch.save(inputs_embeds, output_tts_inputs_embeds_path)

            if self.tts.condition_type == "tts_token_streaming":
                assert tts_tokens_valid_length is not None, "tts_tokens_valid_length should be not None"
                outputs = self.tts.generate_mock_legacy_streaming(
                    inputs_embeds=inputs_embeds,
                    sampling_params=tts_sampling_params,
                    eos_token=torch.tensor(
                        [self.tts.config.num_audio_tokens - 1],
                        dtype=torch.long,
                        device=self.tts.device,
                    ),
                    valid_text_length=tts_tokens_valid_length,
                )
            else:
                outputs = self.tts.generate(
                    inputs_embeds=inputs_embeds,
                    sampling_params=tts_sampling_params,
                    eos_token=torch.tensor(
                        [self.tts.config.num_audio_tokens - 1],
                        dtype=torch.long,
                        device=self.tts.device,
                    ),
                )

        if self.tts.config.audio_tokenizer_type == "wavtokenizer":
            generated_tokens = outputs.new_ids.squeeze(-1)
            features = self.tts.audio_tokenizer.codes_to_features(generated_tokens)
            bandwidth_device = features.device
            waveform_pred = self.tts.audio_tokenizer.decode(
                features,
                bandwidth_id=torch.tensor([0], device=bandwidth_device),
            ).squeeze()
        elif self.tts.config.audio_tokenizer_type == "bicodec":
            with tempfile.NamedTemporaryFile(suffix=".wav") as temp_wav:
                sf.write(temp_wav.name, audio_prompt, 16000)
                global_tokens, semantic_tokens_ = self.tts.audio_tokenizer.tokenize(temp_wav.name)
                print("audio_prompt global_tokens.shape", global_tokens.shape)
                print("audio_prompt semantic_tokens_.shape", semantic_tokens_.shape)

            # print("global_tokens", global_tokens)
            # print("generated_tokens", generated_tokens)
            generated_tokens = outputs.new_ids.squeeze(-1)
            waveform_pred = self.tts.audio_tokenizer.detokenize(global_tokens.squeeze(0), generated_tokens)
            print("waveform_pred.shape", waveform_pred.shape)
        elif self.tts.config.audio_tokenizer_type == "s3tokenizer":
            generated_tokens = outputs.new_ids.squeeze(-1)
            # 注入音色
            reference_audio = audio_prompt
            if reference_audio is not None:
                print("use reference audio in data to generate waveform")
                prompt_speech_16k = torch.tensor(reference_audio).unsqueeze(0)

            if self.tts.config.s3_stream_generate:
                # s3tokenizer streaming generation by yileitu
                print(f"ℹ️ℹ️ℹ️ Using model `minicpm4-3b-s3` ℹ️ℹ️ℹ️")
                print(f"ℹ️ℹ️ℹ️ Using s3tokenizer streaming generation ℹ️ℹ️ℹ️")
                print(f"ℹ️ℹ️ℹ️ generated_tokens shape: {generated_tokens.shape} ℹ️ℹ️ℹ️")
                print(f"ℹ️ℹ️ℹ️ prompt_speech_16k shape: {prompt_speech_16k.shape} ℹ️ℹ️ℹ️")

                waveform_pred = self.tts.audio_tokenizer.inference_token2wav(
                    speech_tokens=generated_tokens,
                    prompt_speech_16k=prompt_speech_16k,
                    prompt_speech=None,
                    stream=True,
                    n_timesteps=self.tts.config.s3_stream_n_timesteps,
                    code_chunk_size=self.tts.config.s3_stream_chunk_size,
                    chunk_prelook_size=self.tts.config.s3_stream_prelook_size,
                    use_attn_idx=False,
                )
                return waveform_pred[0]
            else:
                for i, j in enumerate(
                    self.tts.audio_tokenizer.token2wav(
                        speech_token=generated_tokens,
                        speech_token_len=torch.tensor([generated_tokens.shape[1]], device=generated_tokens.device),
                        prompt_speech_16k=prompt_speech_16k,
                        stream=False,
                    )
                ):
                    waveform_pred = j["tts_speech"]
                    waveform_sample_rate = self.tts.audio_tokenizer.sample_rate  # 24000 here, not 16000 input.
                return waveform_pred[0]
        elif self.tts.config.audio_tokenizer_type == "chattts":
            generated_tokens = outputs.new_ids.permute(0, 2, 1)  # [1, seq_len, num_vq]-> [1, num_vq, seq_len]
            waveform_pred = self.tts.audio_tokenizer.decode(generated_tokens)
        else:
            raise NotImplementedError
        return waveform_pred

    def reset_session(self):
        """
        流式API 清空本轮对话 目前一个模型实例 只支持一个session
        """
        self.llm_past_key_values = None
        self.audio_past_key_values = None  # apm kv cache
        self.tts_last_turn_tokens = None
        self.token2wav_cache = None  # audio token2wav cache
        self.llm_generated = False  # 上轮对话是否是llm生成的
        self.new_user_msg = True  # 是否是新用户

        # 执行一下cuda clear cache
        torch.cuda.empty_cache()
        # 垃圾回收
        # gc.collect()

    @torch.inference_mode()
    def init_token2wav_cache(self, prompt_speech_16k):
        """
        初始化token2wav cache，用于流式生成音频
        """

        model_input = self.tts.audio_tokenizer.frontend.frontend_token2wav(
            speech_tokens=torch.zeros(1, 1, dtype=torch.long, device=self.tts.device),
            # 用prompt模拟一下speech_tokens 这里的500是随便写的。
            speech_16k=None,
            prompt_speech_16k=prompt_speech_16k,
            resample_rate=self.tts.audio_tokenizer.sample_rate,
            prompt_speech=None,
        )

        prompt_token = model_input["flow_prompt_speech_token"]
        prompt_feat = model_input["prompt_speech_feat"]
        embedding = model_input["flow_embedding"]

        if self.tts.audio_tokenizer.fp16:
            prompt_feat = prompt_feat.to(torch.half)
            embedding = embedding.to(torch.half)

        prepared_cache = self.tts.audio_tokenizer.model.prepare_cache_from_prompt(
            prompt_token=prompt_token,
            prompt_feat=prompt_feat,
            embedding=embedding,
            n_timesteps=self.tts.config.s3_stream_n_timesteps,  # 改了，从config里读取
            code_chunk_size=self.tts.config.s3_stream_chunk_size,  # 改了，从config里读取
            chunk_prelook_size=self.tts.config.s3_stream_prelook_size,  # 改了，从config里读取
            use_attn_idx=False,
        )

        self.token2wav_cache = prepared_cache

        return

    @torch.inference_mode()
    def init_token2wav_cache_step_audio(self, prompt_speech_16k):
        self.tts.audio_tokenizer.cache = None
        # 将系统提示音频保存为 16kHz wav，作为 prompt_wav 供 Step-Audio 使用

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp_wav:
            prompt_wav_path = tmp_wav.name
            sf.write(prompt_wav_path, prompt_speech_16k, 16000)
            flow_cache_base, hift_cache_base = self.tts.audio_tokenizer.set_stream_cache(prompt_wav_path)

        self.token2wav_cache = {
            "flow_cache_base": torch_clone_recursive(flow_cache_base),
            "hift_cache_base": torch_clone_recursive(hift_cache_base),
        }

        return

    @torch.inference_mode()
    def streaming_prefill(self, msgs, tokenizer, omni_input=True, max_slice_nums=None, **kwargs):
        # 判断是否是第一轮对话
        if self.llm_past_key_values is None:  # new session
            self.is_first = True  # 判断为第一轮
        else:
            self.is_first = False

        images = []
        audios = []

        assert len(msgs) == 1
        copy_msgs = deepcopy(msgs)
        msg = copy_msgs[0]

        assert msg["role"] in ["system", "user", "assistant"]

        content = msg["content"]
        cur_msgs = []
        for j, c in enumerate(content):
            if isinstance(c, Image.Image):
                images.append(c)
                cur_msgs.append("(<image>./</image>)")
            elif isinstance(c, np.ndarray):  # audio
                audios.append(c)
                cur_msgs.append("(<audio>./</audio>)")
            elif isinstance(c, str):
                cur_msgs.append(c)
            else:
                print("Invalid content type:", c)

        cur_contents = "".join(cur_msgs) if omni_input else "\n".join(cur_msgs)

        if not self.is_first and self.new_user_msg and msg["role"] == "user":  # new user add im_start

            self.audio_past_key_values = None  # 新msg，清空audio_past_key_values

            # 如果上轮对话是llm生成的，那么需要添加 tts eos + im_end，并且添加im_start
            if self.llm_generated:
                msg["content"] = "<|tts_eos|><|im_end|>\n<|im_start|>user\n" + cur_contents
            else:
                msg["content"] = "<|im_end|>\n<|im_start|>user\n" + cur_contents

            self.new_user_msg = False

        else:  # 一个user的turn内，继续prefill
            msg["content"] = cur_contents

        if msg["role"] in ["system", "assistant"]:
            self.new_user_msg = True
            self.audio_past_key_values = None  # apm kv cache

        if self.is_first:
            # init pask_key_values

            # 这里一定要 add_generation_prompt=False，不要自动添加 spk emb tts bos 等token，等在streaming_generate里再添加作为引物
            prompt = tokenizer.apply_chat_template(
                copy_msgs,
                tokenize=False,
                add_generation_prompt=False,
                chat_template=self.default_tts_chat_template,
            )
            add_special_tokens = True  # add bos

            print("[streaming_prefill] first prefill prompt", prompt)
        else:
            prompt = copy_msgs[0]["content"]
            print("[streaming_prefill] following prefill prompt", prompt)
            add_special_tokens = False

        model_inputs = self.processor(
            [prompt],
            [images],
            [audios],
            max_slice_nums=1 if max_slice_nums is None else max_slice_nums,
            use_image_id=False,
            chunk_input=True,
            return_tensors="pt",
            max_length=None,
            sampling_rate=16000,
            add_special_tokens=add_special_tokens,
        ).to(self.device)

        print("streaming_prefill:: prompt: ", prompt)
        print("streaming_prefill:: model_inputs: ", model_inputs)

        # 1. prepare input embeddings
        model_inputs["inputs_embeds"], _ = self.get_vllm_embedding(model_inputs)

        # get audio embedding with audio_past_key_values (core)
        inputs_embeds = self.get_omni_embedding(
            model_inputs,
            input_embeddings=model_inputs["inputs_embeds"],
            stream_input=False,
        )

        if self.is_first:
            # clean audio_past_key_values after first prefill
            self.audio_past_key_values = None

        if self.llm_past_key_values is not None:
            cache_length = self.llm_past_key_values[0][0].shape[2]
        else:
            cache_length = 0

        attention_mask = torch.ones(
            (1, cache_length + inputs_embeds.shape[1]),
            dtype=torch.bool,
            device=self.device,
        )

        # 2. do prefill, call llm directly, no use hf mixin
        outputs = self.llm(
            past_key_values=self.llm_past_key_values,
            inputs_embeds=inputs_embeds,
            attention_mask=attention_mask,
            position_ids=None,  # position_ids,
            use_cache=True,
            return_dict=True,
        )

        self.llm_past_key_values = outputs["past_key_values"]

        return

    @torch.inference_mode()
    def streaming_generate(
        self,
        tokenizer,
        bos_input=None,
        max_new_tokens=256,
        temperature=0.7,
        top_p=0.8,
        top_k=20,
        do_sample=True,
        repetition_penalty=1.05,
        audio_token_chunk_size=25,  # 25token/s
        generate_audio=True,  # 是否生成音频，一定会生成文本，音频可选
        tts_sampling_params=None,  # 音频生成采样参数
        **kwargs,
    ):

        # 先干这么两个事情
        self.new_user_msg = True
        self.llm_generated = True

        # 重置当前轮的 streaming 文本缓存，保证每一轮只保存本轮新生成的文本
        if hasattr(self, "_streaming_generated_text_chunks"):
            del self._streaming_generated_text_chunks
        if hasattr(self, "_last_streaming_text"):
            del self._last_streaming_text

        # 现场创建一个迭代器，在迭代器内令llm按chunk=10生成token和hidden序列，然后令tts按chunk=25生成audio token chunk，每次yield 1个chunk的audio token
        def audio_chunk_generator(
            bos_input,
            max_new_tokens,
            tokenizer,
            temperature,
            top_p,
            top_k,
            do_sample,
            repetition_penalty,
            generate_audio,
            tts_sampling_params,
        ):
            """
            流式chunk生成器
            """
            generate_chunk_size = 10  # fixed value

            if bos_input is None:
                if self.config.tts_config.use_speaker_embedding:
                    bos_input = "<|im_end|>\n<|im_start|>assistant\n<|spk_bos|><|spk|><|spk_eos|><|tts_bos|>"
                else:
                    bos_input = "<|im_end|>\n<|im_start|>assistant\n<|tts_bos|>"
            else:
                print(f"using custom bos_input = {bos_input}")

            bos_input_ids = tokenizer.encode(bos_input)
            bos_input_ids = torch.tensor(bos_input_ids, dtype=torch.long, device=self.device).unsqueeze(0)

            print(f"streaming_generate:: bos_input: {bos_input}, bos_input_ids: {bos_input_ids}")

            # from IPython import embed; embed()
            # time.sleep(3)

            bos_input_embeds = self.llm.get_input_embeddings()(bos_input_ids)

            if self.config.tts_config.use_speaker_embedding:
                assert bos_input_ids.shape[0] == 1, "batch size must be 1"
                assert (
                    len(torch.where(bos_input_ids.squeeze(0) == tokenizer.convert_tokens_to_ids("<|spk|>"))) == 1
                ), "spk token must appear once"

                spk_emb_idx = torch.where(bos_input_ids.squeeze(0) == tokenizer.convert_tokens_to_ids("<|spk|>"))[0]

                print(f"[streaming_generate] spk_emb_idx: {spk_emb_idx}")

            generation_inputs_embeds = bos_input_embeds
            generated_ids = torch.empty((1, 0), dtype=torch.long, device=self.device)

            # 分chunk解码的最大chunk数量
            num_chunks_decode = (max_new_tokens + generate_chunk_size - 1) // generate_chunk_size

            # tts_repetition_penalty = 1.05
            # Chunk TTS 部分
            conditions = []

            # TODO: 分chunk生成，每个chunk 10个token，每个chunk取出他的last hidden states，连同token 传给tts。
            logits_warpers, logits_processors = gen_logits(
                num_code=self.tts.config.num_audio_tokens,
                repetition_penalty=tts_sampling_params.repetition_penalty,
                top_P=tts_sampling_params.top_p,
                top_K=tts_sampling_params.top_k,
            )

            # 流式prefill+generate管理器
            llm_streaming_generator = ChunkPrefillChunkGenerate(
                model=self.llm,
                tokenizer=tokenizer,
                terminators=["<|tts_eos|>", "<|im_end|>", "</s>"],  # "<|tts_eos|>"
            )

            if generate_audio:
                tts_streaming_generator = TTSStreamingGenerator(
                    model=self.tts,
                    temperature=tts_sampling_params.temperature,
                    eos_token=torch.tensor(
                        [self.tts.config.num_audio_tokens - 1],
                        dtype=torch.long,
                        device=self.tts.device,
                    ),
                    chunk_size=audio_token_chunk_size,  # s3tokenizer 1s = 25token
                    tts_last_turn_tokens=self.tts_last_turn_tokens,
                    logits_processors=logits_processors,
                    logits_warpers=logits_warpers,
                )

            # LLM chunk generate 外循环
            for chunk_idx in range(num_chunks_decode):
                is_first_generate_chunk = chunk_idx == 0

                output = llm_streaming_generator._generate_chunk(  # cursor不要改了
                    inputs_embeds=generation_inputs_embeds,
                    past_key_values=self.llm_past_key_values,  # self.llm_past_key_values会被in-place增加长度，直接给进去，不复制了
                    tokenizer=tokenizer,
                    is_first_generate_chunk=is_first_generate_chunk,
                    chunk_size=generate_chunk_size + 1 * is_first_generate_chunk,
                    # 第一个chunk 需要多生成 1个token，才能得到 generate_chunk_size 个 last hidden states + tokens
                    temperature=temperature,
                    top_p=top_p,
                    top_k=top_k,
                    do_sample=do_sample,
                    return_hidden_states=True,
                    repetition_penalty=repetition_penalty,
                    all_input_ids=generated_ids,
                )

                if output.chunk_token_ids is None:
                    print(f"Chunk generator: no token generated, stop generating.")
                    break

                if is_first_generate_chunk:
                    # 处理speaker embedding
                    if generate_audio and self.config.tts_config.use_speaker_embedding:
                        # from IPython import embed; embed()
                        # time.sleep(3)

                        spk_emb = output.input_last_hidden_states[:, spk_emb_idx, :]
                        print(
                            f"streaming_generate:: output.input_last_hidden_states: {output.input_last_hidden_states.shape}"
                        )
                        print(f"streaming_generate:: spk_emb_idx: {spk_emb_idx}")

                        print(f"using speaker embedding, spk_emb.shape: {spk_emb.shape}")

                        spk_emb = self.tts.projector_spk(spk_emb)
                        spk_emb = F.normalize(spk_emb, p=2, dim=-1)
                        print("projected spk_emb.shape", spk_emb.shape)

                    elif generate_audio:
                        # 给一个长度为0的tensor就行
                        # 维度1为0，维度0和维度2和bos_input_embeds一致
                        spk_emb = torch.empty(
                            (bos_input_embeds.shape[0], 0, bos_input_embeds.shape[2]),
                            dtype=bos_input_embeds.dtype,
                            device=bos_input_embeds.device,
                        )
                        print(
                            "no speaker embedding, using empty spk_emb.shape",
                            spk_emb.shape,
                        )

                    if generate_audio:
                        tts_streaming_generator.spk_emb = spk_emb

                    if output.finished:
                        yield_chunk_token_ids = output.chunk_token_ids
                    else:
                        # 第一个chunk生成了 chunk_size + 1个token，我们只取前 chunk_size 个 token，最后一个token 没有prefill，还没有获取last hidden states
                        yield_chunk_token_ids = output.chunk_token_ids[:, :-1]

                elif output.finished:  # 最后一个chunk
                    yield_chunk_token_ids = torch.cat([generated_ids[:, -1:], output.chunk_token_ids], dim=1)

                else:
                    # 在不是第一个chunk的chunk里，需要补上 previous chunk结束时结尾的那个token，它没有被prefill进模型拿到last hidden
                    # print(f"generated_ids.shape: {generated_ids.shape}")
                    # print(f"output.chunk_token_ids.shape: {output.chunk_token_ids.shape}")
                    # 同样的，后续chunk的last generated token 也没有prefill，没有获取last hidden states，所以也不传出去
                    yield_chunk_token_ids = torch.cat([generated_ids[:, -1:], output.chunk_token_ids[:, :-1]], dim=1)

                # 如果只生成文本，直接yield文本token
                if not generate_audio:
                    chunk_generated_text = tokenizer.decode(yield_chunk_token_ids[0])
                    print(
                        "[streaming_generate] chunk_generated_text:",
                        chunk_generated_text,
                    )
                    yield yield_chunk_token_ids, output.finished
                else:
                    # TTS 内循环
                    print("yield_chunk_token_ids.shape", yield_chunk_token_ids.shape)
                    # print("output.last_hidden_states.shape", output.last_hidden_states.shape)
                    # 0716 19:48 进展: 现在实现了按chunk生成 text token + hidden states，每次返回一个chunk的text token + hidden states
                    # 稠密连接 这里写死 使用 text-hidden merged 作为 condition
                    # print("using llm tokens & hidden merged, sliced llm_tokens", yield_chunk_token_ids.shape)
                    llm_embeds = self.tts.emb_text(
                        yield_chunk_token_ids
                    )  # make sure emb_text is compatible with llm vocab size
                    hidden_embeds = output.last_hidden_states
                    hidden_embeds = self.tts.projector_semantic(hidden_embeds)
                    if self.tts.config.normalize_projected_hidden:  # 默认应该打开
                        # print("normalizing hidden_embeds")
                        hidden_embeds = F.normalize(hidden_embeds, p=2, dim=-1)
                    tts_embeds = llm_embeds + hidden_embeds
                    conditions.append(tts_embeds)
                    # decode chunk_generated_ids
                    chunk_generated_text = tokenizer.decode(yield_chunk_token_ids[0])
                    print(
                        "[streaming_generate] chunk_generated_text:",
                        chunk_generated_text,
                    )
                    # 将文本追加到 streaming 文本缓存中，方便外部（如 Web 后端）记录每轮回复的完整文本
                    if not hasattr(self, "_streaming_generated_text_chunks"):
                        self._streaming_generated_text_chunks = []
                    self._streaming_generated_text_chunks.append(chunk_generated_text)
                    # print("tts_embeds.shape", tts_embeds.shape)
                    # print("-> generating audio tokens")

                    # 有 buffer 生成，每次恰好返回 25 个 audio token，最后一个audio chunk返回不定长度的audio token，长度 [0, 25]
                    tts_generator = tts_streaming_generator.generate_with_buffer(
                        condition=tts_embeds, text_finished=output.finished
                    )

                    # 从生成器中逐个获取 token
                    # 注意，一段 condition 可生成多个audio chunk，中间可能不需要频繁再给进去新的condition！
                    for (
                        audio_token_chunk,
                        is_last_audio_chunk,
                    ) in tts_generator:  # 如果上述没有yield出来任何东西，那么进入下一个llm chunk generate
                        # 每次生成1个音频token
                        # 在这里可以每接收到几个token就decode一次音频
                        print(f"Yielded chunk of audio tokens: {audio_token_chunk.shape}")  # 形状会是 [1, chunk_size]
                        # 每次 yield 出来一个 chunk 的 audio token，就可以立刻开始进行 token2wav 变成 1s 的音频
                        print("---> audio_token_chunk", audio_token_chunk)

                        yield audio_token_chunk, is_last_audio_chunk
                        # all_yielded_tts_tokens.append(audio_token_chunk)

                # 更新 generated_ids
                generated_ids = torch.cat([generated_ids, output.chunk_token_ids], dim=1)
                generation_inputs_embeds = output.current_inputs_embeds

                # 刷新past_key_values（上面是inplace给的）
                # past_key_values = output.past_key_values

                # 如果生成结束，退出循环
                if output.finished:
                    if generate_audio:
                        self.tts_last_turn_tokens = tts_streaming_generator.tts_last_turn_tokens
                    break

            # 收尾工作
            if generate_audio:
                # 生成结束时，将所有 chunk 的文本拼接，形成本轮完整回复文本
                if hasattr(self, "_streaming_generated_text_chunks"):
                    try:
                        self._last_streaming_text = "".join(self._streaming_generated_text_chunks)
                    except Exception:
                        self._last_streaming_text = None
                else:
                    self._last_streaming_text = None

                # 最后发出结束信号！！
                yield None, None
            else:
                # 否则就直接退出
                return

        # 创建迭代器，用于生成文本chunk和音频chunk
        audio_chunk_generator_iter = audio_chunk_generator(
            bos_input=bos_input,
            max_new_tokens=max_new_tokens,
            tokenizer=tokenizer,
            temperature=temperature,
            top_p=top_p,
            top_k=top_k,
            do_sample=do_sample,
            repetition_penalty=repetition_penalty,
            generate_audio=generate_audio,
            tts_sampling_params=tts_sampling_params,
        )

        generate_waveform = True
        if generate_audio:
            if generate_waveform:
                if self.tts.config.audio_tokenizer_type == "s3tokenizer":
                    for waveform_pred in self.tts.audio_tokenizer.model.token2wav_stream_with_prepared_cache(
                        token_iterator=audio_chunk_generator_iter,
                        prepared_cache=self.token2wav_cache,
                        uuid=str(uuid.uuid1()),
                        use_two_stage_hift=False,
                        use_hift_cache=True,
                        use_torch_stft=True,
                    ):
                        # print(f"full streaming mode:: waveform_pred.shape={waveform_pred.shape}")
                        yield waveform_pred
                        # wav_chunks.append(waveform_pred)

                elif self.tts.config.audio_tokenizer_type == "s3tokenizer_step_audio":
                    self.tts.audio_tokenizer.stream_cache = torch_clone_recursive(
                        self.token2wav_cache["flow_cache_base"]
                    )
                    self.tts.audio_tokenizer.hift_cache_dict = torch_clone_recursive(
                        self.token2wav_cache["hift_cache_base"]
                    )

                    # 初始化 cache 统计基线与 CUDA 显存基线
                    prev_sc_bytes = _cuda_tensor_bytes(self.tts.audio_tokenizer.stream_cache)
                    prev_hc_bytes = _cuda_tensor_bytes(self.tts.audio_tokenizer.hift_cache_dict)
                    torch.cuda.synchronize()
                    prev_alloc = torch.cuda.memory_allocated()
                    prev_resv = torch.cuda.memory_reserved()
                    prev_peak = torch.cuda.max_memory_allocated()

                    # 预先放入 3-5 个前缀 4218 静音 token，每个token对应 0.04s 加入5个意味着引入0.2s的空白
                    buffer = [4218] * 3
                    pre_lookahead = 3
                    CHUNK_SIZE = 25
                    chunk_idx = 0
                    for (
                        audio_token_chunk,
                        is_last_audio_chunk,
                    ) in audio_chunk_generator_iter:
                        if audio_token_chunk is None:
                            break

                        # print("audio_token_chunk.shape", audio_token_chunk.shape)
                        # print("audio_token_chunk.squeeze().tolist()", audio_token_chunk.squeeze().tolist())

                        buffer += audio_token_chunk.reshape(-1).tolist()

                        if len(buffer) >= CHUNK_SIZE + pre_lookahead:
                            waveform_chunk = self.tts.audio_tokenizer.stream(
                                buffer[: CHUNK_SIZE + pre_lookahead],
                                prompt_wav=None,
                                last_chunk=is_last_audio_chunk,
                                return_waveform=True,
                            )
                            # 转换成numpy waveform
                            waveform_chunk = torch.from_numpy(waveform_chunk)

                            # 统计 token2wav cache 的显存占用
                            sc_bytes = _cuda_tensor_bytes(self.tts.audio_tokenizer.stream_cache)
                            hc_bytes = _cuda_tensor_bytes(self.tts.audio_tokenizer.hift_cache_dict)
                            d_sc_bytes = sc_bytes - prev_sc_bytes
                            d_hc_bytes = hc_bytes - prev_hc_bytes
                            print(
                                f"\033[35m[chunk={chunk_idx}] <cache> stream_cache VRAM: {_fmt_bytes(sc_bytes)} (+{_fmt_bytes(d_sc_bytes)}) | hift_cache_dict VRAM: {_fmt_bytes(hc_bytes)} (+{_fmt_bytes(d_hc_bytes)})\033[0m"
                            )

                            # 打印 CUDA 实际显存占用
                            torch.cuda.synchronize()
                            cur_alloc = torch.cuda.memory_allocated()
                            cur_resv = torch.cuda.memory_reserved()
                            peak_alloc = (
                                torch.cuda.max_memory_alloced()
                                if hasattr(torch.cuda, "max_memory_alloced")
                                else torch.cuda.max_memory_allocated()
                            )
                            d_alloc_bytes = cur_alloc - prev_alloc
                            d_resv_bytes = cur_resv - prev_resv
                            d_peak_bytes = peak_alloc - prev_peak
                            print(
                                f"\033[33m[chunk={chunk_idx}] <cuda> allocated: {_fmt_bytes(cur_alloc)} (+{_fmt_bytes(d_alloc_bytes)}) | reserved: {_fmt_bytes(cur_resv)} (+{_fmt_bytes(d_resv_bytes)}) | peak_alloc: {_fmt_bytes(peak_alloc)} (+{_fmt_bytes(d_peak_bytes)})\033[0m"
                            )

                            # 更新基线
                            prev_sc_bytes = sc_bytes
                            prev_hc_bytes = hc_bytes
                            prev_alloc = cur_alloc
                            prev_resv = cur_resv
                            prev_peak = peak_alloc

                            print("will yield waveform_chunk", waveform_chunk.shape)
                            yield waveform_chunk
                            buffer = buffer[CHUNK_SIZE:]  # 滑动一个chunk
                            chunk_idx += 1

                    # Flush 余量
                    if len(buffer) > 0:
                        waveform_chunk = self.tts.audio_tokenizer.stream(
                            buffer,
                            prompt_wav=None,
                            last_chunk=True,
                            return_waveform=True,
                        )
                        # 转换成numpy waveform
                        waveform_chunk = torch.from_numpy(waveform_chunk)

                        # flush 阶段也统计一次显存
                        sc_bytes = _cuda_tensor_bytes(self.tts.audio_tokenizer.stream_cache)
                        hc_bytes = _cuda_tensor_bytes(self.tts.audio_tokenizer.hift_cache_dict)
                        d_sc_bytes = sc_bytes - prev_sc_bytes
                        d_hc_bytes = hc_bytes - prev_hc_bytes
                        print(
                            f"\033[35m<cache-flush> stream_cache VRAM: {_fmt_bytes(sc_bytes)} (+{_fmt_bytes(d_sc_bytes)}) | hift_cache_dict VRAM: {_fmt_bytes(hc_bytes)} (+{_fmt_bytes(d_hc_bytes)})\033[0m"
                        )

                        torch.cuda.synchronize()
                        cur_alloc = torch.cuda.memory_allocated()
                        cur_resv = torch.cuda.memory_reserved()
                        peak_alloc = (
                            torch.cuda.max_memory_alloced()
                            if hasattr(torch.cuda, "max_memory_alloced")
                            else torch.cuda.max_memory_allocated()
                        )
                        d_alloc_bytes = cur_alloc - prev_alloc
                        d_resv_bytes = cur_resv - prev_resv
                        d_peak_bytes = peak_alloc - prev_peak
                        print(
                            f"\033[33m<cuda-flush> allocated: {_fmt_bytes(cur_alloc)} (+{_fmt_bytes(d_alloc_bytes)}) | reserved: {_fmt_bytes(cur_resv)} (+{_fmt_bytes(d_resv_bytes)}) | peak_alloc: {_fmt_bytes(peak_alloc)} (+{_fmt_bytes(d_peak_bytes)})\033[0m"
                        )

                        print("will yield waveform_chunk", waveform_chunk.shape)
                        yield waveform_chunk

                else:
                    raise NotImplementedError(f"不支持的音频分词器类型: {self.tts.config.audio_tokenizer_type}")
            else:
                for _ in audio_chunk_generator_iter:
                    yield torch.randn((1, 24000), device=self.device)
        else:
            # 只生成文本，直接yield文本token
            for text_tokens, is_finished in audio_chunk_generator_iter:
                yield text_tokens, is_finished

        # generated_waveform = torch.cat(wav_chunks, dim=-1)
        # generated_waveform = generated_waveform[0] # [1, num_samples] -> [num_samples]

        # sf.write(output_audio_path, generated_waveform.cpu().numpy(), samplerate=24000)
        # print(f"full streaming mode:: audio saved to {output_audio_path}")

        return


class MiniCPMWhisperEncoderLayer(nn.Module):
    def __init__(self, config: WhisperConfig, layer_idx: int = None):
        super().__init__()
        self.embed_dim = config.d_model
        try:
            # compatible old transformers
            from transformers.models.whisper.modeling_whisper import WHISPER_ATTENTION_CLASSES

            self.self_attn = WHISPER_ATTENTION_CLASSES[config._attn_implementation](
                embed_dim=self.embed_dim,
                num_heads=config.encoder_attention_heads,
                dropout=config.attention_dropout,
                config=config,
                layer_idx=layer_idx,
            )
        except:
            from transformers.models.whisper.modeling_whisper import WhisperAttention

            self.self_attn = WhisperAttention(
                embed_dim=self.embed_dim,
                num_heads=config.encoder_attention_heads,
                dropout=config.attention_dropout,
                config=config,
                layer_idx=layer_idx,
            )

        self.self_attn_layer_norm = nn.LayerNorm(self.embed_dim)
        self.dropout = config.dropout
        self.activation_fn = ACT2FN[config.activation_function]
        self.activation_dropout = config.activation_dropout
        self.fc1 = nn.Linear(self.embed_dim, config.encoder_ffn_dim)
        self.fc2 = nn.Linear(config.encoder_ffn_dim, self.embed_dim)
        self.final_layer_norm = nn.LayerNorm(self.embed_dim)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor,
        layer_head_mask: torch.Tensor,
        output_attentions: bool = False,
        past_key_values: Optional[EncoderDecoderCache] = None,
        use_cache: Optional[bool] = False,
    ) -> torch.Tensor:
        residual = hidden_states
        hidden_states = self.self_attn_layer_norm(hidden_states)
        hidden_states, attn_weights, past_key_values = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            layer_head_mask=layer_head_mask,
            output_attentions=output_attentions,
            past_key_value=past_key_values,
        )
        hidden_states = nn.functional.dropout(hidden_states, p=self.dropout, training=self.training)
        hidden_states = residual + hidden_states

        residual = hidden_states
        hidden_states = self.final_layer_norm(hidden_states)
        hidden_states = self.activation_fn(self.fc1(hidden_states))
        hidden_states = nn.functional.dropout(hidden_states, p=self.activation_dropout, training=self.training)
        hidden_states = self.fc2(hidden_states)
        hidden_states = nn.functional.dropout(hidden_states, p=self.dropout, training=self.training)
        hidden_states = residual + hidden_states

        if hidden_states.dtype == torch.float16 and (
            torch.isinf(hidden_states).any() or torch.isnan(hidden_states).any()
        ):
            clamp_value = torch.finfo(hidden_states.dtype).max - 1000
            hidden_states = torch.clamp(hidden_states, min=-clamp_value, max=clamp_value)

        outputs = (hidden_states,)

        if output_attentions:
            outputs += (attn_weights,)

        if use_cache:
            outputs += (past_key_values,)

        return outputs


class MiniCPMWhisperEncoder(WhisperEncoder):
    def __init__(self, config: WhisperConfig):
        super().__init__(config)
        self.layers = nn.ModuleList(
            [MiniCPMWhisperEncoderLayer(config, layer_idx=i) for i in range(config.encoder_layers)]
        )

    def forward(
        self,
        input_features,
        attention_mask=None,
        head_mask=None,
        output_attentions=None,
        output_hidden_states=None,
        return_dict=None,
        past_key_values: Optional[EncoderDecoderCache] = None,
        use_cache: Optional[bool] = None,
    ):
        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        # Ignore copy
        input_features = input_features.to(dtype=self.conv1.weight.dtype, device=self.conv1.weight.device)

        inputs_embeds = nn.functional.gelu(self.conv1(input_features))
        inputs_embeds = nn.functional.gelu(self.conv2(inputs_embeds))

        inputs_embeds = inputs_embeds.permute(0, 2, 1)

        embed_pos = self.embed_positions.weight
        past_key_values_length = 0
        if use_cache:
            if past_key_values is None:
                past_key_values = EncoderDecoderCache(DynamicCache(), DynamicCache())
            elif isinstance(past_key_values, list):
                past_key_values = EncoderDecoderCache(DynamicCache.from_legacy_cache(past_key_values), DynamicCache())
            elif isinstance(past_key_values, DynamicCache):
                past_key_values = EncoderDecoderCache(past_key_values, DynamicCache())
            else:
                pass
            past_key_values_length = past_key_values.self_attention_cache.get_usable_length(inputs_embeds.shape[1])
            if inputs_embeds.shape[1] + past_key_values_length > embed_pos.shape[0]:
                logger.warning("seems the audio is longer than 30s. repeating the last part of the audio")
                embed_pos_front = embed_pos[past_key_values_length:, :]
                embed_pos = torch.cat(
                    (
                        embed_pos_front,
                        torch.repeat_interleave(
                            embed_pos[-1, :].unsqueeze(0),
                            inputs_embeds.shape[1] - embed_pos.shape[0] + past_key_values_length,
                            dim=0,
                        ),
                    )
                )
            else:
                embed_pos = embed_pos[
                    past_key_values_length : inputs_embeds.shape[1] + past_key_values_length,
                    :,
                ]
        else:
            embed_pos = embed_pos[: inputs_embeds.shape[1], :]

        hidden_states = inputs_embeds + embed_pos
        hidden_states = nn.functional.dropout(hidden_states, p=self.dropout, training=self.training)

        encoder_states = () if output_hidden_states else None
        all_attentions = () if output_attentions else None

        # check if head_mask has a correct number of layers specified if desired
        if head_mask is not None:
            assert head_mask.size()[0] == (
                len(self.layers)
            ), f"The head_mask should be specified for {len(self.layers)} layers, but it is for {head_mask.size()[0]}."

        for idx, encoder_layer in enumerate(self.layers):
            if output_hidden_states:
                encoder_states = encoder_states + (hidden_states,)
            # add LayerDrop (see https://arxiv.org/abs/1909.11556 for description)
            to_drop = False
            if self.training:
                dropout_probability = torch.rand([])
                if dropout_probability < self.layerdrop:  # skip the layer
                    to_drop = True

            # Ignore copy
            if to_drop:
                layer_outputs = (None, None)
            else:
                if self.gradient_checkpointing and self.training:
                    layer_outputs = self._gradient_checkpointing_func(
                        encoder_layer.__call__,
                        hidden_states,
                        attention_mask,
                        (head_mask[idx] if head_mask is not None else None),
                        output_attentions,
                        past_key_values,
                        use_cache,
                    )
                else:
                    layer_outputs = encoder_layer(
                        hidden_states,
                        attention_mask,
                        layer_head_mask=(head_mask[idx] if head_mask is not None else None),
                        output_attentions=output_attentions,
                        past_key_values=past_key_values,
                        use_cache=use_cache,
                    )

                hidden_states = layer_outputs[0]

            if use_cache:
                next_encoder_cache = layer_outputs[2 if output_attentions else 1]
            else:
                next_encoder_cache = None

            if output_attentions:
                all_attentions = all_attentions + (layer_outputs[1],)

        hidden_states = self.layer_norm(hidden_states)
        if output_hidden_states:
            encoder_states = encoder_states + (hidden_states,)

        if not return_dict:
            return tuple(v for v in [hidden_states, encoder_states, all_attentions] if v is not None)
        return BaseModelOutputWithPast(
            last_hidden_state=hidden_states,
            hidden_states=encoder_states,
            attentions=all_attentions,
            past_key_values=next_encoder_cache,
        )


class MultiModalProjector(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.linear1 = nn.Linear(in_features=in_dim, out_features=out_dim, bias=True)
        self.relu = nn.ReLU()
        self.linear2 = nn.Linear(in_features=out_dim, out_features=out_dim, bias=True)

    def forward(self, audio_features):
        hidden_states = self.relu(self.linear1(audio_features))
        hidden_states = self.linear2(hidden_states)
        return hidden_states


class MiniCPMMLP(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        self.in_dim = config.llm_hidden_size
        self.out_dim = config.hidden_size
        self.intermediate_size = config.llm_intermediate_size
        self.gate_proj = nn.Linear(self.in_dim, self.intermediate_size, bias=True)
        self.up_proj = nn.Linear(self.in_dim, self.intermediate_size, bias=True)
        self.down_proj = nn.Linear(self.intermediate_size, self.out_dim, bias=True)
        self.act_fn = ACT2FN[config.hidden_act]

    def forward(self, x):
        down_proj = self.down_proj(self.act_fn(self.gate_proj(x)) * self.up_proj(x))

        return down_proj


@dataclass
class MiniCPMTTSGenerationOutput(ModelOutput):
    """
    Output class for MiniCPMTTS generation.

    Args:
        new_ids (torch.LongTensor): Newly generated audio code sequence, shape (batch_size, sequence_length, num_vq).
        audio_input_ids (torch.LongTensor): Updated input IDs including condition and generated audio codes, shape (batch_size, full_sequence_length, num_vq).
        past_key_values (Tuple[Tuple[torch.FloatTensor]]): Tuple containing pre-computed keys and values used for attention mechanism. Each element has shape (batch_size, num_heads, sequence_length, embed_size_per_head).
        finished (bool): Boolean indicating whether generation is complete.
    """

    new_ids: torch.LongTensor = None
    audio_input_ids: torch.LongTensor = None
    past_key_values: Optional[Tuple[Tuple[torch.FloatTensor]]] = None
    past_input_ids: Optional[torch.LongTensor] = None
    finished: bool = None


def make_streaming_chunk_mask_inference(
    tts_text_scope: List[int],
    tts_text_mask: torch.Tensor,
    streaming_audio_chunk_size: int = 50,
    dtype: torch.dtype = torch.bfloat16,
    device: torch.device = torch.device("cuda"),
    max_sequence_length: int = 4096,
):
    """
    Example:
    Input sequence:
    [t1, t2, t3, t4, t5, [Ptts], a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, ...]
    Output 4D causal mask:
    ------- text positions -------
    [0] <- here is [Stts]
    [0,   0] <- here is [spk_emb] * N
    [0,   0,   0]
    [0,   0,   0,    0]
    [0,   0,   0,    0,    0]
    ------- audio positions --------
    [0,    0, -inf, -inf, -inf, 0] <- here is [Ptts], [Ptts]'s last hidden state should predict the first audio token
                                v- here is [Ptts]
    [0,    0, -inf, -inf, -inf, 0, 0]
    [0,    0, -inf, -inf, -inf, 0, 0, 0]
    [0,    0, -inf, -inf, -inf, 0, 0, 0, 0]
    [0,    0, -inf, -inf, -inf, 0, 0, 0, 0, 0]
    [0,    0, -inf, -inf, -inf, 0, 0, 0, 0, 0, 0] # end of first 1s audio chunk
    [0,    0, 0   , -inf, -inf, 0, 0, 0, 0, 0, 0, 0]
    [0,    0, 0   , -inf, -inf, 0, 0, 0, 0, 0, 0, 0, 0]
    [0,    0, 0   , -inf, -inf, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    [0,    0, 0   , -inf, -inf, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    [0,    0, 0   , -inf, -inf, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    """

    # Create a complete attention mask for input embeds [batch_size, seq_len], without considering audio mask as audio is always at the end

    assert tts_text_mask.dtype == torch.int8

    padding_mask = torch.ones(max_sequence_length, dtype=torch.int8, device=device)
    padding_mask[tts_text_scope[0] : tts_text_scope[1]] = tts_text_mask

    # Initialize a standard upper triangular causal mask
    min_dtype = torch.finfo(dtype).min

    causal_mask = torch.full(
        (max_sequence_length, max_sequence_length),
        fill_value=min_dtype,
        dtype=dtype,
        device=device,
    )
    if max_sequence_length != 1:
        causal_mask = torch.triu(causal_mask, diagonal=1)
    else:
        raise ValueError("max_sequence_length of tts could not be 1.")

    # For each data sample
    audio_token_start = tts_text_scope[1]
    audio_duration = max_sequence_length - tts_text_scope[1]

    # Record which text chunk the current audio chunk can see up to
    text_pivot = 0
    num_valid_text_tokens = torch.sum(tts_text_mask).item() - 1  # [Ptts] excluded
    # How many audio chunks are in total, the num of buckets should be smaller as possible

    num_text_tokens_per_audio_chunk = 10

    # For each chunk of audio
    for chunk_idx in range(math.ceil(audio_duration / streaming_audio_chunk_size)):
        audio_chunk_start = audio_token_start + chunk_idx * streaming_audio_chunk_size
        audio_chunk_end = audio_token_start + (chunk_idx + 1) * streaming_audio_chunk_size
        # New text seen by this new audio chunk
        new_text_this_chunk = num_text_tokens_per_audio_chunk
        # The right bound of visible text tokens
        text_pivot = min(new_text_this_chunk + text_pivot, num_valid_text_tokens)
        # Mask all text chunks after the visible ones
        # -> [text_pivot, len(tts_text_scope)-1] excluding [Ptts]
        # print("audio_chunk_start-1", audio_chunk_start-1, "audio_chunk_end-1", audio_chunk_end-1, "tts_text_scope[0] + text_pivot", tts_text_scope[0] + text_pivot, "tts_text_scope[1] - 1", tts_text_scope[1] - 1)
        causal_mask[
            audio_chunk_start - 1 : audio_chunk_end - 1,
            # tts_text_scope[0] + text_pivot: tts_text_scope[1],
            tts_text_scope[0] + text_pivot : tts_text_scope[1] - 1,
        ] = min_dtype

    # Mask the padding parts in tts_text_masks (no position will attend to it)
    causal_mask[:, padding_mask == 0] = min_dtype

    # Add extra dimensions, [batch_size, seq_len, seq_len] -> [batch_size, 1, seq_len, seq_len]
    causal_mask = causal_mask.unsqueeze(0).unsqueeze(0)

    return causal_mask


class MiniCPMTTS(PreTrainedModel):
    config_class = MiniCPMTTSConfig

    def __init__(self, config: MiniCPMTTSConfig, audio_tokenizer: None):
        super().__init__(config)

        self.use_speaker_embedding = config.use_speaker_embedding
        self.use_llm_hidden_state = config.use_llm_hidden_state
        self.num_spk_embs = config.num_spk_embs
        self.spk_emb_token_id = config.spk_emb_token_id

        self.use_text = config.use_text
        self.streaming = config.streaming
        self.streaming_text_chunk_min = config.streaming_text_chunk_min
        self.streaming_text_chunk_max = config.streaming_text_chunk_max
        self.streaming_audio_chunk_size = config.streaming_audio_chunk_size
        self.streaming_text_reserved_len = config.streaming_text_reserved_len
        # streaming tts
        self.streaming_text_chunk_size = config.streaming_text_chunk_max
        self.audio_bos_token_id = config.audio_bos_token_id
        self.num_mel_bins = config.num_mel_bins
        self.num_vq = config.num_vq
        self.num_audio_tokens = config.num_audio_tokens

        self.top_p = config.top_p
        self.top_k = config.top_k
        self.repetition_penalty = config.repetition_penalty

        self.interleaved = config.interleaved
        self.attention_type = config.attention_type
        self.recomputed_chunks = config.recomputed_chunks
        self.window_size = config.window_size
        if self.attention_type == "sliding_recompute" and self.window_size <= self.recomputed_chunks:
            raise ValueError(
                f"Sliding recompute requires window_size > recomputed_chunks, but got window_size={self.window_size} and recomputed_chunks={self.recomputed_chunks}"
            )

        if config.backbone_model == "llama":
            print(f"initializating tts model, using {config.attn_implementation} implementation")
            model_config = LlamaConfig(
                hidden_size=config.hidden_size,
                intermediate_size=config.intermediate_size,
                num_attention_heads=config.num_attention_heads,
                num_hidden_layers=config.num_hidden_layers,
                num_key_value_heads=config.num_key_value_heads,
                max_position_embeddings=config.max_position_embeddings,
                attn_implementation=config.attn_implementation,
            )

            self.emb_text = nn.Embedding(config.num_text_tokens, config.hidden_size)

            model = LlamaModel(model_config)
            self.model = model
        else:
            raise ValueError(f"Unsupported backbone model: {config.backbone_model}")

        self.projector_spk = self.create_projector(config)
        self.projector_semantic = self.create_projector(config)

        self.audio_tokenizer = audio_tokenizer

        self.emb_code = nn.ModuleList(
            [nn.Embedding(config.num_audio_tokens, config.hidden_size) for _ in range(config.num_vq)]
        )

        self.head_code = nn.ModuleList(
            [
                weight_norm(
                    nn.Linear(config.hidden_size, config.num_audio_tokens, bias=False),
                    name="weight",
                )
                for _ in range(config.num_vq)
            ]
        )

        self.condition_type = config.condition_type

        return

    @staticmethod
    def create_projector(config):
        if config.projector_type == "mlp":
            return MultiModalProjector(config.llm_dim, config.hidden_size)
        elif config.projector_type == "minicpm":
            return MiniCPMMLP(config)
        elif config.projector_type == "default":
            return nn.Linear(config.llm_dim, config.hidden_size, bias=False)
        else:
            raise ValueError(f"Unsupported projector type: {config.projector_type}")

    # non-streaming
    @torch.inference_mode()
    def generate(
        self,
        inputs_embeds: torch.Tensor,
        eos_token: Union[int, torch.Tensor],
        force_no_stop=False,
        min_new_token=50,
        max_new_token=2048,
        show_tqdm=True,
        streaming=False,
        text_lengths=None,
        sampling_params: TTSSamplingParams = TTSSamplingParams(),
    ):
        top_p_warper = TopPLogitsWarper(top_p=sampling_params.top_p)
        min_p_warper = MinPLogitsWarper(min_p=sampling_params.min_p)
        top_k_warper = TopKLogitsWarper(top_k=sampling_params.top_k)
        repetition_penalty_processor = RepetitionPenaltyLogitsProcessor(
            penalty=float(sampling_params.repetition_penalty)
        )

        temperature = torch.tensor(
            [sampling_params.temperature] * self.config.num_vq,
            dtype=torch.float,
            device=self.device,
        )
        temperature = (temperature.unsqueeze(0).expand(inputs_embeds.shape[0], -1).contiguous().view(-1, 1)).to(
            inputs_embeds.device
        )

        logits_warpers, logits_processors = gen_logits(
            num_code=self.config.num_audio_tokens,
            repetition_penalty=sampling_params.repetition_penalty,
            top_P=sampling_params.top_p,
            top_K=sampling_params.top_k,
        )

        # We only support batch size `1` for now
        assert inputs_embeds.shape[0] == 1
        eos_token = eos_token.to(inputs_embeds.device)
        finish = torch.zeros(inputs_embeds.shape[0], device=inputs_embeds.device).bool()

        condition_length = inputs_embeds.shape[1]
        pbar: Optional[tqdm] = None
        if show_tqdm:
            pbar = tqdm(
                total=max_new_token,
                desc="code",
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt}(max) [{elapsed}, {rate_fmt}{postfix}]",
            )

        if streaming:
            raise NotImplementedError("this kind of streaming is not supported yet")

        new_tokens = torch.zeros(
            inputs_embeds.shape[0],
            max_new_token,
            self.num_vq,
            device=inputs_embeds.device,
            dtype=torch.long,
        )

        past_key_values = None

        for t in range(max_new_token):
            audio_bos = False
            # If this is the first audio token, the case is special
            if t == 0:
                audio_bos = True
                inputs_embeds = inputs_embeds
                position_ids = torch.tensor(
                    list(range(0, condition_length)),
                    dtype=torch.long,
                    device=self.device,
                ).unsqueeze(0)
                # cache_position = position_ids.clone()

                if streaming:
                    raise NotImplementedError("this kind of streaming is not supported yet")
                else:
                    causal_mask_4d = None

            else:
                code_emb = []
                for q in range(self.num_vq):
                    x = self.emb_code[q](new_tokens[:, t - 1 : t, q])
                    code_emb.append(x)

                inputs_embeds = torch.stack(code_emb, 3).sum(3)

                position_ids = torch.tensor([condition_length + t - 1], dtype=torch.long, device=self.device).unsqueeze(
                    0
                )

                if streaming:
                    raise NotImplementedError("this kind of streaming is not supported yet")
                else:
                    causal_mask_4d = None

            # Model forward
            if self.config.backbone_model == "llama":
                outputs: BaseModelOutputWithPast = self.model(
                    position_ids=position_ids,
                    cache_position=position_ids,
                    past_key_values=past_key_values,
                    inputs_embeds=inputs_embeds,
                    attention_mask=causal_mask_4d,
                    use_cache=True,
                    output_attentions=False,
                    # return_dict=True,  # Add this to ensure returns dict with past_key_values
                )
            # elif self.config.backbone_model == "qwen":
            #     outputs = self.model.model(
            #         inputs_embeds=inputs_embeds,
            #         position_ids=position_ids,
            #         cache_position=position_ids,
            #         past_key_values=past_key_values,
            #         use_cache=True,
            #         output_attentions=False,
            #         attention_mask=causal_mask_4d,
            #         # return_dict=True,
            #     )
            else:
                raise ValueError(f"Unsupported backbone model: {self.config.backbone_model}")

            del position_ids
            del inputs_embeds

            hidden_states = outputs.last_hidden_state
            past_key_values = outputs.past_key_values

            with P.cached():
                logits = torch.empty(
                    hidden_states.size(0),
                    hidden_states.size(1),
                    self.num_audio_tokens,
                    self.num_vq,
                    dtype=torch.float,
                    device=self.device,
                )
                for num_vq_iter in range(self.num_vq):
                    x: torch.Tensor = self.head_code[num_vq_iter](hidden_states)
                    logits[..., num_vq_iter] = x
                    del x

            del hidden_states

            logits = logits[:, -1].float()

            logits = logits.permute(0, 2, 1)
            logits = logits.reshape(-1, logits.size(2))

            logits /= temperature

            if not audio_bos:
                input_ids_sliced = new_tokens[:, 0:t].permute(0, 2, 1)  # get previous t new tokens
                logits_token = input_ids_sliced.reshape(
                    input_ids_sliced.size(0) * input_ids_sliced.size(1),
                    -1,
                ).to(self.device)

                del input_ids_sliced

                for logitsProcessors in logits_processors:
                    logits = logitsProcessors(logits_token, logits)

                for logitsWarpers in logits_warpers:
                    logits = logitsWarpers(logits_token, logits)

                del logits_token

            if t < min_new_token:
                logits[:, eos_token] = -torch.inf

            if force_no_stop:
                logits[:, eos_token] = -torch.inf

            scores = F.softmax(logits, dim=-1)

            del logits

            idx_next = torch.multinomial(scores, num_samples=1).to(finish.device)

            del scores

            idx_next = idx_next.view(-1, self.num_vq)

            finish_or = idx_next.eq(eos_token).any(1)
            finish.logical_or_(finish_or)

            del finish_or
            new_tokens[:, t] = idx_next

            if t == 0 and finish.any():
                break

            del idx_next

            if finish.all():
                break

            if pbar is not None:
                pbar.update(1)

        if pbar is not None:
            pbar.close()

        if not finish.all():
            print(f"incomplete result. hit max_new_token: {max_new_token}")

        genrated_input_ids = new_tokens[:, 0:t, :]

        return MiniCPMTTSGenerationOutput(
            new_ids=genrated_input_ids,
            audio_input_ids=None,  # for update purpose
            past_key_values=None,  # for update purpose
            past_input_ids=None,  # for update purpose
            finished=finish.all(),
        )

    # fake streaming
    @torch.inference_mode()
    def generate_mock_legacy_streaming(
        self,
        inputs_embeds: torch.Tensor,
        eos_token: Union[int, torch.Tensor],
        force_no_stop=False,
        min_new_token=50,
        max_new_token=2048,
        show_tqdm=True,
        streaming=False,
        text_lengths=None,
        sampling_params: TTSSamplingParams = TTSSamplingParams(),
        valid_text_length=None,
    ):
        assert valid_text_length is not None, "valid_text_length should be not None"

        tts_text_scope = [0, inputs_embeds.shape[1]]
        tts_text_mask = torch.zeros(inputs_embeds.shape[1], dtype=torch.int8, device=inputs_embeds.device)
        tts_text_mask[0:valid_text_length] = 1
        tts_text_mask[-1] = 1  # [Ptts]

        streaming_mask_4d_full = make_streaming_chunk_mask_inference(
            tts_text_scope=tts_text_scope,
            tts_text_mask=tts_text_mask,
            dtype=torch.bfloat16,
            device=self.device,
            streaming_audio_chunk_size=50,
            max_sequence_length=4096,
        )

        temperature = torch.tensor([0.1, 0.3, 0.1, 0.3], dtype=torch.float, device=self.device)
        temperature = (temperature.unsqueeze(0).expand(inputs_embeds.shape[0], -1).contiguous().view(-1, 1)).to(
            inputs_embeds.device
        )

        logits_warpers, logits_processors = gen_logits(
            num_code=self.config.num_audio_tokens,
            repetition_penalty=sampling_params.repetition_penalty,
            top_P=sampling_params.top_p,
            top_K=sampling_params.top_k,
        )

        # We only support batch size `1` for now
        assert inputs_embeds.shape[0] == 1
        eos_token = eos_token.to(inputs_embeds.device)
        finish = torch.zeros(inputs_embeds.shape[0], device=inputs_embeds.device).bool()

        condition_length = inputs_embeds.shape[1]
        pbar: Optional[tqdm] = None
        if show_tqdm:
            pbar = tqdm(
                total=max_new_token,
                desc="code",
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt}(max) [{elapsed}, {rate_fmt}{postfix}]",
            )

        new_tokens = torch.zeros(
            inputs_embeds.shape[0],
            max_new_token,
            self.num_vq,
            device=inputs_embeds.device,
            dtype=torch.long,
        )

        past_key_values = None

        for t in range(max_new_token):
            audio_bos = False
            if t == 0:
                audio_bos = True
                inputs_embeds = inputs_embeds
                position_ids = torch.tensor(
                    list(range(0, condition_length)),
                    dtype=torch.long,
                    device=self.device,
                ).unsqueeze(0)

                causal_mask_4d = streaming_mask_4d_full[:, :, :condition_length, :condition_length]
                print("t=0, causal_mask_4d.shape", causal_mask_4d.shape)
            else:
                code_emb = []
                for q in range(self.num_vq):
                    x = self.emb_code[q](new_tokens[:, t - 1 : t, q])
                    code_emb.append(x)

                inputs_embeds = torch.stack(code_emb, 3).sum(3)

                position_ids = torch.tensor([condition_length + t - 1], dtype=torch.long, device=self.device).unsqueeze(
                    0
                )

                causal_mask_4d = streaming_mask_4d_full[
                    :,
                    :,
                    condition_length + t : condition_length + t + 1,
                    : condition_length + t,
                ]

                # get length of past_key_values
                past_key_values_length = past_key_values[0][0].shape[2]

                assert causal_mask_4d.shape[-1] == (past_key_values_length + 1)

                if t < 20 and t % 2 == 0:
                    print("past_key_values_length", past_key_values_length)
                    print(f"t={t}, causal_mask_4d.shape", causal_mask_4d.shape)

            # Model forward
            if self.config.backbone_model == "llama":
                outputs: BaseModelOutputWithPast = self.model(
                    position_ids=position_ids,
                    cache_position=position_ids,
                    past_key_values=past_key_values,
                    inputs_embeds=inputs_embeds,
                    attention_mask=causal_mask_4d,
                    use_cache=True,
                    output_attentions=False,
                    # return_dict=True,  # Add this to ensure returns dict with past_key_values
                )
            # elif self.config.backbone_model == "qwen":
            #     outputs = self.model.model(
            #         inputs_embeds=inputs_embeds,
            #         position_ids=position_ids,
            #         cache_position=position_ids,
            #         past_key_values=past_key_values,
            #         use_cache=True,
            #         output_attentions=False,
            #         attention_mask=causal_mask_4d,
            #         # return_dict=True,
            #     )
            else:
                raise ValueError(f"Unsupported backbone model: {self.config.backbone_model}")

            del position_ids
            del inputs_embeds

            hidden_states = outputs.last_hidden_state
            past_key_values = outputs.past_key_values

            with P.cached():
                logits = torch.empty(
                    hidden_states.size(0),
                    hidden_states.size(1),
                    self.num_audio_tokens,
                    self.num_vq,
                    dtype=torch.float,
                    device=self.device,
                )
                for num_vq_iter in range(self.num_vq):
                    x: torch.Tensor = self.head_code[num_vq_iter](hidden_states)
                    logits[..., num_vq_iter] = x
                    del x

            del hidden_states

            logits = logits[:, -1].float()
            logits = logits.permute(0, 2, 1)
            logits = logits.reshape(-1, logits.size(2))
            logits /= temperature

            if not audio_bos:
                input_ids_sliced = new_tokens[:, 0:t].permute(0, 2, 1)  # get previous t new tokens

                logits_token = input_ids_sliced.reshape(
                    input_ids_sliced.size(0) * input_ids_sliced.size(1),
                    -1,
                ).to(self.device)

                del input_ids_sliced

                for logitsProcessors in logits_processors:
                    logits = logitsProcessors(logits_token, logits)

                for logitsWarpers in logits_warpers:
                    logits = logitsWarpers(logits_token, logits)

                del logits_token

            if t < min_new_token:
                logits[:, eos_token] = -torch.inf

            if force_no_stop:
                logits[:, eos_token] = -torch.inf

            scores = F.softmax(logits, dim=-1)

            del logits
            idx_next = torch.multinomial(scores, num_samples=1).to(finish.device)

            del scores

            idx_next = idx_next.view(-1, self.num_vq)
            finish_or = idx_next.eq(eos_token).any(1)
            finish.logical_or_(finish_or)

            del finish_or
            new_tokens[:, t] = idx_next

            if t == 0 and finish.any():
                break

            del idx_next

            if finish.all():
                break

            if pbar is not None:
                pbar.update(1)

        if pbar is not None:
            pbar.close()

        if not finish.all():
            print(f"incomplete result. hit max_new_token: {max_new_token}")

        genrated_input_ids = new_tokens[:, 0:t, :]

        return MiniCPMTTSGenerationOutput(
            new_ids=genrated_input_ids,
            audio_input_ids=None,  # for update purpose
            past_key_values=None,  # for update purpose
            past_input_ids=None,  # for update purpose
            finished=finish.all(),
        )

    # non-streaming, interleave
    @torch.inference_mode()
    def generate_chunk(
        self,
        inputs_embeds: torch.Tensor,
        temperature: torch.Tensor,
        repetition_penalty: float,
        eos_token: Union[int, torch.Tensor],
        force_no_stop=False,
        max_new_token=500,
        min_new_tokens=0,
        past_key_values=None,
        logits_processors=None,
        text_start_pos=None,
    ):
        """
        For inputs_embeds, it should be like [bs=1, seq_len, hidden_dim], its content is like:
        |Text BOS|Spk embeds|Text-Hidden states Interleave (if applicable)|Audio BOS|
        where the last position is the audio BOS token.
        So, the first iteration in generation directly forward the model with inputs_embeds, and the last hidden states of the last position (Audio BOS) will be decoded to get the first audio token.
        """
        # self.model.eval()
        logits_warpers, logits_processors = gen_logits(
            num_code=self.config.num_audio_tokens, repetition_penalty=repetition_penalty
        )  # , top_K=20 repetition_penalty=1.0 top_P=0.9,

        # We only support batch size `1` for now
        assert inputs_embeds.shape[0] == 1
        eos_token = eos_token.to(inputs_embeds.device)
        finish = torch.zeros(inputs_embeds.shape[0], device=inputs_embeds.device).bool()

        temperature = (temperature.unsqueeze(0).expand(inputs_embeds.shape[0], -1).contiguous().view(-1, 1)).to(
            inputs_embeds.device
        )

        condition_length = inputs_embeds.shape[1]

        new_tokens = torch.zeros(
            inputs_embeds.shape[0],
            max_new_token,
            self.num_vq,
            device=inputs_embeds.device,
            dtype=torch.long,
        )

        for t in range(max_new_token):
            # print("generating {}-th token".format(t))
            # Prepare generation inputs

            audio_bos = False

            # If this is the first audio token, the case is special
            if t == 0:
                audio_bos = True
                inputs_embeds_ = inputs_embeds
                position_ids = torch.tensor(
                    list(range(text_start_pos, text_start_pos + condition_length)),
                    dtype=torch.long,
                    device=self.device,
                ).unsqueeze(0)

                # cache_position = position_ids.clone()

            else:
                # Generate the following audio tokens, it is applicable to all other cases, including second and the following calling of `generate`

                # print("new_tokens[:, t-1:t, q]", new_tokens[:, t-1:t, :])
                # Simplified version for num_vq=1
                inputs_embeds_ = self.emb_code[0](new_tokens[:, t - 1 : t, 0])

                position_ids = torch.tensor(
                    [text_start_pos + condition_length + t - 1],  # 把上一个token prefill进去
                    dtype=torch.long,
                    device=self.device,
                ).unsqueeze(0)

                # cache_position = position_ids.clone()

            outputs: BaseModelOutputWithPast = self.model(
                position_ids=position_ids,
                # cache_position=position_ids,
                past_key_values=past_key_values,
                inputs_embeds=inputs_embeds_,
                use_cache=True,
                output_attentions=False,
                # return_dict=True,  # Add this to ensure returns dict with past_key_values
            )

            # outputs = self.model.model(
            #     inputs_embeds=inputs_embeds_,
            #     position_ids=position_ids,
            #     cache_position=position_ids,
            #     past_key_values=past_key_values,
            #     use_cache=True,
            #     output_attentions=False,
            #     # return_dict=True,
            # )

            del position_ids
            del inputs_embeds_

            # if streaming_mask_v1 is not None:
            #     print(f"t={t}, outputs.past_key_values[0][0].shape={outputs.past_key_values[0][0].shape}")

            hidden_states = outputs.last_hidden_state
            past_key_values = outputs.past_key_values

            # print("past_key_values 0,0", past_key_values[0][0].shape)
            # print("hidden_states", hidden_states.shape)

            with P.cached():
                logits = torch.empty(
                    hidden_states.size(0),
                    hidden_states.size(1),
                    self.num_audio_tokens,
                    self.num_vq,
                    dtype=torch.float,
                    device=self.device,
                )
                for num_vq_iter in range(self.num_vq):
                    x: torch.Tensor = self.head_code[num_vq_iter](hidden_states)
                    logits[..., num_vq_iter] = x
                    del x

            del hidden_states

            logits = logits[:, -1].float()
            # logits = logits.narrow(1, -1, 1).squeeze_(1).float()

            # logits = rearrange(logits, "b c n -> (b n) c")
            logits = logits.permute(0, 2, 1)
            logits = logits.reshape(-1, logits.size(2))
            # logits_token = rearrange(input_ids[:, start_idx:], "b c n -> (b n) c")

            logits /= temperature

            if not audio_bos:
                input_ids_sliced = new_tokens[:, 0:t].permute(0, 2, 1)  # get previous t new tokens
                # print("input_ids_sliced", input_ids_sliced.shape)

                logits_token = input_ids_sliced.reshape(
                    input_ids_sliced.size(0) * input_ids_sliced.size(1),
                    -1,
                ).to(self.device)

                del input_ids_sliced

                for logitsProcessors in logits_processors:
                    logits = logitsProcessors(logits_token, logits)

                # for logitsWarpers in logits_warpers:
                #     logits = logitsWarpers(logits_token, logits)

                del logits_token

            if force_no_stop or t < min_new_tokens:
                logits[:, eos_token] = -torch.inf

            scores = F.softmax(logits, dim=-1)
            logp = logits.squeeze(0)
            del logits

            # idx_next  = ras_sampling(logp, new_tokens[:, 0: t], sampling=25, top_p=0.8,min_p=0.01, top_k=25, win_size=10, tau_r=0.1)
            idx_next = torch.multinomial(scores, num_samples=1).to(finish.device)
            del scores

            # idx_next = rearrange(idx_next, "(b n) 1 -> b n", n=self.num_vq)
            idx_next = idx_next.view(-1, self.num_vq)

            # print("idx_next", idx_next)

            finish_or = idx_next.eq(eos_token).any(1)
            finish.logical_or_(finish_or)

            del finish_or
            # 新的 `token` 存入 `input_ids_buf`
            new_tokens[:, t] = idx_next

            if t == 0 and finish.any():
                # raise Exception
                break

            del idx_next

            if finish.all():
                break

        if not finish.all():
            print(f"incomplete result. hit max_new_token: {max_new_token}")

        # if finish.all():
        #     # the last may contains eos token
        #     genrated_input_ids = new_tokens[0:t]
        # else:
        #     # there is no eos token
        genrated_input_ids = new_tokens[
            :, 0:t, :
        ]  # 最新生成的那个token不在此次返回的范围内，如果是eos token，不返回，如果是其他正常的token，也不返回。正常！

        # print("genrated_input_ids inner", genrated_input_ids.shape)
        return genrated_input_ids, past_key_values

    @torch.inference_mode()
    def interleaved_generate(
        self,
        spk_embeds: torch.Tensor,
        conditions: List[torch.Tensor],
        temperature: torch.Tensor,
        repetition_penalty: float,
        eos_token: Union[int, torch.Tensor],
        **kwargs,
    ):
        """
        For inputs_embeds, it should be like [bs=1, seq_len, hidden_dim], its content is like:
        |Text BOS|Spk embeds|Text-Hidden states Interleave (if applicable)|Audio BOS|
        where the last position is the audio BOS token.
        So, the first iteration in generation directly forward the model with inputs_embeds, and the last hidden states of the last position (Audio BOS) will be decoded to get the first audio token.
        """
        if self.config.use_speaker_embedding:
            spk_embeds = spk_embeds.unsqueeze(0)

        temperature = torch.tensor([temperature], dtype=torch.float, device=self.device)
        # self.model.eval()
        logits_warpers, logits_processors = gen_logits(
            num_code=self.config.num_audio_tokens,
            repetition_penalty=repetition_penalty,
        )
        # , top_K=20 repetition_penalty=1.0 top_P=0.9,

        eos_token = eos_token.to(conditions[0].device)

        num_chunks = len(conditions)
        text_start_pos = 0
        last_window_size = 0
        past_key_values = None

        for idx in range(num_chunks):
            condition = conditions[idx].to(conditions[0].device)
            if idx == 0 and self.config.use_speaker_embedding:
                condition = torch.cat([spk_embeds, condition], dim=1)

            if self.attention_type == "sliding_recompute":
                recomputed_conditions = [spk_embeds]

                if (
                    idx >= self.window_size
                    and (idx - self.recomputed_chunks) % (self.window_size - self.recomputed_chunks) == 0
                ):
                    for i in range(self.recomputed_chunks):
                        recomputed_conditions.append(conditions[idx - self.recomputed_chunks + i])
                        recomputed_conditions.append(
                            self.emb_code[0](generated_tokens[-self.recomputed_chunks + i][:, :, 0])
                        )
                    recomputed_conditions.append(condition)
                    condition = torch.cat(recomputed_conditions, dim=1)

                    text_start_pos = 0
                    new_tokens, old_kv = self.generate_chunk(
                        inputs_embeds=condition,
                        temperature=temperature,
                        repetition_penalty=repetition_penalty,
                        eos_token=eos_token,
                        force_no_stop=False,
                        max_new_token=500,
                        past_key_values=None,
                        logits_processors=logits_processors,
                        text_start_pos=text_start_pos,
                    )

                else:
                    new_tokens, old_kv = self.generate_chunk(
                        inputs_embeds=condition,
                        temperature=temperature,
                        repetition_penalty=repetition_penalty,
                        eos_token=eos_token,
                        force_no_stop=False,
                        max_new_token=500,
                        past_key_values=past_key_values,
                        logits_processors=logits_processors,
                        text_start_pos=text_start_pos,
                    )

            else:
                new_tokens, old_kv = self.generate_chunk(
                    inputs_embeds=condition,
                    temperature=temperature,
                    repetition_penalty=repetition_penalty,
                    eos_token=eos_token,
                    force_no_stop=False,
                    max_new_token=500,
                    past_key_values=past_key_values,
                    logits_processors=logits_processors,
                    text_start_pos=text_start_pos,
                )

                print("this chunk new_tokens.shape", new_tokens.shape)

            past_key_values = []
            if self.attention_type == "sliding_window" and idx >= 1:
                for layer_idx in range(len(old_kv)):
                    past_key_values.append(
                        (
                            old_kv[layer_idx][0][:, :, last_window_size:, :],
                            old_kv[layer_idx][1][:, :, last_window_size:, :],
                        )
                    )
            else:
                past_key_values = old_kv

            last_window_size = condition.shape[1] + new_tokens.shape[1]
            text_start_pos += last_window_size

            if idx == 0:
                generated_tokens = [new_tokens]
            else:
                # generated_tokens = torch.cat([generated_tokens, new_tokens], dim=1)
                generated_tokens.append(new_tokens)

        return MiniCPMTTSGenerationOutput(
            new_ids=torch.cat(generated_tokens, dim=1),
            finished=True,
        )


class CustomRepetitionPenaltyLogitsProcessorRepeat:
    def __init__(self, penalty: float, max_input_ids: int, past_window: int):
        if not isinstance(penalty, float) or not (penalty > 0):
            raise ValueError(f"`penalty` has to be a strictly positive float, but is {penalty}")

        self.penalty = penalty
        self.max_input_ids = max_input_ids
        self.past_window = past_window

    def __call__(self, input_ids: torch.LongTensor, scores: torch.FloatTensor) -> torch.FloatTensor:
        if input_ids.size(1) > self.past_window:
            input_ids = input_ids.narrow(1, -self.past_window, self.past_window)
        freq = F.one_hot(input_ids, scores.size(1)).sum(1)
        if freq.size(0) > self.max_input_ids:
            freq.narrow(0, self.max_input_ids, freq.size(0) - self.max_input_ids).zero_()
        alpha = torch.pow(self.penalty, freq)
        scores = scores.contiguous()
        inp = scores.multiply(alpha)
        oth = scores.divide(alpha)
        con = scores < 0
        out = torch.where(con, inp, oth)
        del inp, oth, scores, con, alpha
        return out


def gen_logits(
    num_code: int,
    top_P=0.7,
    top_K=20,
    repetition_penalty=1.0,
):
    logits_warpers = []
    if top_P is not None:
        logits_warpers.append(TopPLogitsWarper(top_P, min_tokens_to_keep=3))
    if top_K is not None:
        logits_warpers.append(TopKLogitsWarper(top_K, min_tokens_to_keep=3))

    logits_processors = []
    if repetition_penalty is not None and repetition_penalty != 1:
        logits_processors.append(CustomRepetitionPenaltyLogitsProcessorRepeat(repetition_penalty, num_code, 16))

    return logits_warpers, logits_processors
