"""Verify and benchmark the original bincount contracts on one ON compiler.

The accuracy-only mode checks both implementations repeatedly without timing.
Formal mode first performs those same checks, then runs the frozen three paired
rounds and qualifies bincount alone using the median of paired speedups.
Original inputs, integer oracles, and production implementations are unchanged.
"""

import argparse
import ast
import copy
import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import runpy
import sys
import traceback


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(8 * 1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument("--phase", choices=("cold", "warm"), required=True)
parser.add_argument("--prefix", default="/compilercandidate")
parser.add_argument("--compile-commands", required=True)
parser.add_argument("--manifest", required=True)
parser.add_argument("--source-prefix", required=True)
parser.add_argument("--contract-source", default="/probe/test_v2_penalty_bincount.original.py")
parser.add_argument("--accuracy-only", action="store_true")
parser.add_argument("--output", required=True)
args = parser.parse_args()
manifest = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
assert manifest["purpose"] == "scalar-i1-atomic-dma-release-candidate"
candidate_config = {
    "scalar-i1-atomic-dma-candidate": (
        "3cdcac1f30065663a043ccb7960447c79b4e10b6793de34de9967b9a6081850b",
        "62cc3c7c9c03cc7d4b7a2359ec20c2994efe7ef78e98fcac5b74c41e35c131d0", "OFF"),
    "scalar-i1-atomic-dma-release-candidate": (
        "3affaf4e67a85705c1869ef8d9049b356469c0e9dcf10b5cde907405b074fad0",
        "753d15fb9a90d96a8a0ecebbf13a95a59adbf4904be539d3245e93429999ddf1", "ON"),
}
numeric_diff, cpp_sha, required_conceal = candidate_config[manifest["purpose"]]
assert manifest["source_base_commit"] == "e6a8799cc14819def1bdb8fe68b018fd774fe4c9"
assert len(manifest["source_commit"]) == 40 and all(c in "0123456789abcdef" for c in manifest["source_commit"])
assert manifest["diagnostic_cmake_delta_sha256"] == "85287cef5755a9ed21fc63a4dd2649d8e3ba12e0146f8909f276e1dde75d46ee"
conceal = manifest["cmake_options"]["TRITON_XPU_CONCEAL_IR"]
assert conceal == required_conceal
assert manifest["numeric_delta_sha256"] == numeric_diff
assert manifest["numeric_cpp_source_unchanged_from_base"] is False
assert manifest["pin_mismatch"] is True
assert manifest["llvm19_archive_actual_sha256"] == "9b9b088d925cc885d7ae6af2d93e57c84a27c55b02829327677c059678ecc9c7"
assert manifest["llvm19_archive_actual_md5"] == "87e03d05123cf01ec246ad54c1ac57a9"
assert manifest["llvm19_archive_source_md5_prefix"] == "d1eb1e77"
assert manifest["compiler_py_sha256"] == "8971d25e7145279bc330d3bd3e4080a020b15d2208d2886bbbb13ee95b23f6e2"
for checksum in (manifest["core_sha256"], manifest["wheel_sha256"], *manifest["assets_sha256"].values()):
    assert len(checksum) == 64 and all(c in "0123456789abcdef" for c in checksum)
assert len(manifest["assets_sha256"]) == 9
source_prefix = Path(args.source_prefix).resolve()
source_expected = {
    "cmake/FlagTreeOptions.cmake": "153b9a03188f332340ada4dd60ea5e2bc718a3b931d519acd703146a6b7a0ddd",
    "third_party/xpu/lib/Conversion/TritonXPUToLLVM/LoadStoreOpToLLVM.cpp": cpp_sha,
    "third_party/xpu/lib/Dialect/TritonXPU/Transforms/Mask.cpp": "c10e95ececa542bfd10f349594a0f46623428089b142079eb99ac572b8a0725d",
    "python/setup_tools/utils/xpu.py": "8e0f98c40eb97338949db9a382795dbc747b7a1acd83b386eb5450d7e46241e3",
    "python/setup_tools/setup_helper.py": "87d404730778f6b6dca1b608b29f0b31a997696f5243158494b245618e7b1da2",
}
for relative, expected in source_expected.items():
    assert digest(source_prefix / relative) == expected, relative
assert manifest["source_files_sha256"] == source_expected
assert manifest["assets_sha256"] == {'llvm_trust': '09c1746c272c98872bdeb0aee0806423c95c88305aa1bbaee8c9c97bde7d810a', 'llvm-pub22': 'b6ca59dd2a057f4b760fe8c91471575cd2b8d8d9176f9e4a931dcd8bb30c85a6', 'xre-Linux-x86_64': 'c08e6175aff8d764408899a28c25a17f2a3ce890dfbae7312705e7d9183b6077', 'xpu-device-libs': '5e86cbc3083ec59f304111336097614685628998a38f80e22de684dcdcd2bb3d', 'xpu-sdnn-objects_v0.3.6.9.1': '7e318ccf05757845610239bd64d7a69735dc0cf7e49cdb9b96958a0c62812927', 'xpu-python-impl-so_v0.3.6.9.2': 'dcb8b8e49600f3f8e22d503b0c6b68a0551fe9eb95636f1c7400896337259e7f', 'xtdk-llvm19_20261013': '9b9b088d925cc885d7ae6af2d93e57c84a27c55b02829327677c059678ecc9c7', 'xtdk-llvm19-printf': '05a7608c3584296cd695f29599317bc84ec7b967b79f696af9ccea349787aebb', 'xpu-runtime-so': '1331e351fa6997f9d3083cde42abe7c50c05ee75fa2f49729efa6049339951d9'}
compile_commands_path = Path(args.compile_commands)
assert digest(compile_commands_path) == manifest["compile_commands_sha256"]
compile_commands = json.loads(compile_commands_path.read_text(encoding="utf-8"))
commands_checked = []
for suffix in ("third_party/xpu/python/src/ir.cc", "third_party/xpu/triton_xpu.cc"):
    matches = [entry for entry in compile_commands if entry["file"].replace("\\", "/").endswith(suffix)]
    assert len(matches) == 1, (suffix, len(matches))
    command = matches[0].get("command") or " ".join(matches[0]["arguments"])
    if conceal == "OFF":
        assert "TRITON_CONCEAL_IR" not in command, (suffix, command)
    else:
        assert "-DTRITON_CONCEAL_IR=1" in command, (suffix, command)
        assert "-UTRITON_CONCEAL_IR" not in command, (suffix, command)
    commands_checked.append(suffix)

prefix = Path(args.prefix).resolve()
contract_source = Path(args.contract_source).resolve()
report = {
    "phase": args.phase,
    "timing_run": False,
    "production_pin_changed": False,
    "source_commit_candidate": manifest["source_commit"],
    "source_base_commit": manifest["source_base_commit"],
    "diagnostic_compile_commands_checked": commands_checked,
    "whole_wheel_expected_sha256": manifest["wheel_sha256"],
    "numeric_delta_sha256": manifest["numeric_delta_sha256"],
    "isolated_numeric_candidate_manifest": manifest,
    "conceal_option": conceal,
    "release_style_conceal_enabled": conceal == "ON",
    "source_files_sha256": source_expected,
    "not_byte_identical_release_build": True,
    "wrapper_block_size": 1024,
    "provider_imported": False,
    "checks": [],
}


def require_in_prefix(path):
    path = Path(path).resolve()
    assert path.is_relative_to(prefix), (str(path), str(prefix))
    return path


def absent_provider():
    bad = [n for n in sys.modules if n.startswith(("flaggems_vllm", "vllm_fl"))]
    assert not bad, bad


def tensor_identity(tensor):
    cpu = tensor.detach().cpu().contiguous()
    return {
        "dtype": str(tensor.dtype),
        "shape": list(tensor.shape),
        "stride": list(tensor.stride()),
        "sha256": hashlib.sha256(cpu.numpy().tobytes()).hexdigest(),
    }


try:
    # Disable only plugin/provider discovery for native identity isolation.
    # No operator whitelist or alternate native reference is introduced.
    os.environ["VLLM_PLUGINS"] = ""
    os.environ["USE_FLAGGEMS"] = "0"
    for name in (
        "VLLM_FL_FLAGOS_WHITELIST",
        "VLLM_FL_FLAGOS_BLACKLIST",
        "VLLM_FL_FLAGOS_BLACKLIST_APPEND",
    ):
        assert not os.environ.get(name), name
    assert sys.version_info[:2] == (3, 10), sys.version
    assert digest(contract_source) == "f1a7df5f23efcb06a395695b8001909179e114917644e92f729fce429e6d3015"
    cache = Path(os.environ["TRITON_CACHE_DIR"]).resolve()
    cache.mkdir(parents=True, exist_ok=True)
    initial_files = sorted(str(p.relative_to(cache)) for p in cache.rglob("*") if p.is_file())
    assert bool(initial_files) == (args.phase == "warm"), (args.phase, initial_files[:10])
    report["cache_files_before"] = len(initial_files)
    report["original_contract_source_sha256"] = digest(contract_source)
    report["original_b254_reproducer_executed_by_this_helper"] = False

    import torch
    import triton
    import triton._C.libtriton as core
    from triton.backends.xpu import compiler as backend

    compiler_path = require_in_prefix(backend.__file__)
    core_path = require_in_prefix(core.__file__)
    triton_path = require_in_prefix(triton.__file__)
    assert digest(compiler_path) == "8971d25e7145279bc330d3bd3e4080a020b15d2208d2886bbbb13ee95b23f6e2"
    assert digest(core_path) == manifest["core_sha256"]
    assert core_path.stat().st_size == manifest["core_bytes"]
    assert importlib.metadata.version("flagtree") == manifest["flagtree_version"]
    assert triton.__version__ == "3.6.0", triton.__version__
    assert torch.__version__ == "2.9.0+cu129", torch.__version__
    absent_provider()
    assert torch.cuda.device_count() == 1, torch.cuda.device_count()
    torch.cuda.set_device(0)
    report.update({
        "python": sys.version.split()[0],
        "torch": torch.__version__,
        "triton": triton.__version__,
        "flagtree": importlib.metadata.version("flagtree"),
        "triton_module": str(triton_path),
        "compiler_module": str(compiler_path),
        "compiler_py_sha256": digest(compiler_path),
        "core_module": str(core_path),
        "core_sha256": digest(core_path),
        "device_name": torch.cuda.get_device_name(0),
        "cache_directory": str(cache),
        "compiler_knobs": {
            k: v for k, v in os.environ.items()
            if k.startswith(("TRITONXPU_", "TRITON_XPU_", "TRITON_LLVM19_"))
        },
    })
    print(json.dumps({"preflight": report}), flush=True)

    native = importlib.import_module("vllm.v1.worker.gpu.sample.penalties")
    absent_provider()
    assert not getattr(native, "_vllm_fl_kunlunxin_penalties_provider", False)
    assert native.bincount.__module__ == "vllm.v1.worker.gpu.sample.penalties"
    native_source = Path(inspect.getsourcefile(native.bincount)).resolve()
    assert digest(native_source) == "a5e99c71e6ac50ef025b8a7b0b903a1d2679738d8319af9c98bb200389388b29"
    assert "BLOCK_SIZE = 1024" in inspect.getsource(native.bincount)
    report["native_source_sha256"] = digest(native_source)
    report["vllm_metadata_version"] = importlib.metadata.version("vllm")
    tree = ast.parse(contract_source.read_text())
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)
                 and node.name == "test_v2_penalty_bincount"]
    assert len(functions) == 1
    original_function = functions[0]
    parametrize = [node for node in original_function.decorator_list
                   if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                   and node.func.attr == "parametrize"]
    assert len(parametrize) == 1
    cases = ast.literal_eval(parametrize[0].args[1])
    assert cases == [(167, 185), (151939, 185), (151939, 2048), (167, 0)]
    function = copy.deepcopy(original_function)
    function.name = "_native_original_contract"
    function.decorator_list = []
    calls_changed = 0
    for node in ast.walk(function):
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and isinstance(node.func.value, ast.Name)
                and node.func.value.id == "flaggems_vllm"
                and node.func.attr == "v2_penalty_bincount"):
            # The only computational AST change: dispatch to the unmodified
            # upstream native wrapper. Inputs and CPU assertions are unchanged.
            node.func.value.id = "native"
            node.func.attr = "bincount"
            calls_changed += 1
    assert calls_changed == 1
    before_return_ast = ast.dump(function, include_attributes=False)
    returned_state = ast.Return(value=ast.Call(func=ast.Name(id="locals", ctx=ast.Load()), args=[], keywords=[]))
    ast.copy_location(returned_state, function.body[-1])
    function.body.append(returned_state)
    executable = ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[]))
    namespace = {"torch": torch, "native": native}
    exec(compile(executable, str(contract_source), "exec"), namespace)
    run_contract = namespace["_native_original_contract"]
    report["original_contracts"] = cases
    report["AST_adaptation"] = "Remove pytest vendor/parametrize decorators; rename host test; replace only provider call target with native.bincount; append locals return after all original assertions. Kernel, shapes, dtypes, seed, input generation, and integer oracle are untouched."
    report["adapted_host_AST_sha256"] = hashlib.sha256(before_return_ast.encode()).hexdigest()
    identities = {}
    contract_states = {}
    failures = []
    for repeat in range(1 if args.phase == "cold" else 3):
        for vocab, max_prefill_len in cases:
            state = None
            error = None
            try:
                state = run_contract(vocab, max_prefill_len)
            except Exception as exc:
                error = {"type": type(exc).__name__, "message": str(exc)}
                traceback.print_exc()
                tb = exc.__traceback__
                while tb is not None:
                    if tb.tb_frame.f_code is run_contract.__code__:
                        state = tb.tb_frame.f_locals.copy()
                    tb = tb.tb_next
                if any(term in error["message"].lower() for term in
                       ("illegal memory access", "device-side assert", "noc timeout", "noc error")):
                    report["checks"].append({"repeat": repeat, "vocab": vocab,
                        "max_prefill_len": max_prefill_len, "error": error,
                        "stopped_after_device_fault": True})
                    raise RuntimeError("Stopped fixed-fixture check after device fault; original exception saved") from exc
            absent_provider()
            assert state is not None
            identity = {name: tensor_identity(state[name]) for name in
                        ("ids", "mapping", "prompt_len", "prefill_len")}
            assert state["mapping"].tolist() == [3, 1]
            assert state["ids"].dtype == torch.int32
            assert list(state["ids"].shape) == [4, max(190, max_prefill_len)]
            assert state["mapping"].dtype == torch.int64
            assert state["prompt_len"].dtype == state["prefill_len"].dtype == torch.int32
            if max_prefill_len == 2048:
                assert state["prompt_len"].tolist() == [513] * 4
                assert state["prefill_len"].tolist() == [2048] * 4
                assert (state["ids"][:, 520::133] == 31).all()
                assert (state["ids"][:, 670::217] == vocab - 1).all()
            elif max_prefill_len == 0:
                assert state["prompt_len"].tolist() == [0] * 4
                assert state["prefill_len"].tolist() == [0] * 4
            else:
                assert state["prompt_len"].tolist() == [20, 135, 0, 72]
                assert state["prefill_len"].tolist() == [44, 185, 0, 175]
            key = f"{vocab}-{max_prefill_len}"
            if key not in identities:
                identities[key] = identity
            assert identity == identities[key]
            words = (vocab + 31) // 32
            packed_stride = list(state["packed_gpu"][:, :words].stride())
            count_stride = list(state["counts_gpu"][:, :vocab].stride())
            assert packed_stride == [words + 2, 1]
            assert count_stride == [vocab + 5, 1]
            check = {"repeat": repeat, "vocab": vocab, "max_prefill_len": max_prefill_len,
                     "input_identity": identity, "packed_view_stride": packed_stride,
                     "count_view_stride": count_stride,
                     "expected_backing_identity": {name: tensor_identity(state[name]) for name in
                         ("expected_packed", "expected_counts")},
                     "actual_backing_identity": {name: tensor_identity(state[name]) for name in
                         ("packed_gpu", "counts_gpu")},
                     "integer_oracle": "pass" if error is None else "fail",
                     "error": error}
            if error is not None:
                failures.append(check)
                snapshot_dir = Path(args.output).parent / "failed-contract-snapshots"
                snapshot_dir.mkdir(exist_ok=True)
                snapshot_path = snapshot_dir / f"{args.phase}-{key}-repeat{repeat}.pt"
                torch.save({name: value.detach().cpu() for name, value in state.items()
                            if isinstance(value, torch.Tensor)}, snapshot_path)
                check["failed_tensor_snapshot"] = str(snapshot_path)
                check["failed_tensor_snapshot_sha256"] = digest(snapshot_path)
            report["checks"].append(check)
            contract_states[key] = state
            print(json.dumps(check), flush=True)
    report["input_identity_by_contract"] = identities
    if failures:
        raise AssertionError(f"{len(failures)} native original-contract checks failed; no shape, threshold, or reference changes")
    # Native-only original four contracts have passed above. Importing the
    # provider for comparison must not replace either original vLLM callable.
    original_native = native.bincount
    original_kernel = native._bincount_kernel
    triton_identity = triton
    core_identity = core
    import flaggems_vllm as gems
    import triton.testing
    assert gems.vendor_name == "kunlunxin", gems.vendor_name
    candidate_function = gems.v2_penalty_bincount
    provider_root = Path(inspect.getfile(gems)).resolve().parent
    expected_provider_files = {'ops/v2_apply_grammar_bitmask.py': 'f92098a5c34402681b8fe935dce9d341944b1f0ac352eb37f76460cfd34029f9', 'ops/v2_apply_penalties.py': '2090c435b1d20105444cd25de4b9067e33fc6d17bbab41fabb392f632d63f97d', 'ops/v2_penalty_bincount.py': 'd970ada69717129a12792fcd5752c19b4789887802cdd7c79fb39e74b0aeaf52', 'runtime/backend/_kunlunxin/ops/v2_apply_grammar_bitmask.py': 'b5fdff1ea192306eeb5ad4a778346adc3016e24a4134bccf2896dadfd50c5a02', 'runtime/backend/_kunlunxin/ops/v2_sampling_penalties.py': '3da93760934f48e94378e6dde41a2f6d70c4235b21c70abc6016522e039c5bc3'}
    actual_provider_files = {}
    for relative, expected_sha in expected_provider_files.items():
        actual_sha = digest(provider_root / relative)
        assert actual_sha == expected_sha, (relative, actual_sha, expected_sha)
        actual_provider_files[relative] = actual_sha
    report["provider_files_equal_b495_and_baked8ae"] = actual_provider_files
    report["provider_imported"] = True
    report["native_preflight_provider_imported"] = False
    report["native_provider_marker"] = False
    report["timing_run"] = not args.accuracy_only
    report["protocol"] = {"warmup_ms": 1000, "rep_ms": 100,
        "measurement": "triton.testing.do_bench(return_mode=median)",
        "pairs": 3, "order": [["native", "gems"], ["gems", "native"], ["native", "gems"]],
        "aggregation": "primary: median of 3 paired native_ms/gems_ms speedups; secondary only: ratio of latency medians",
        "per_case_threshold": 0.9, "active_set": cases, "empty_case_included": True,
        "new_bincount_benchmark": "No existing V2 bincount benchmark file; reuse all four frozen PR1248 contracts with original upstream native wrapper as baseline. Generic torch.bincount is not used as a timing reference.",
        "same_compiler_and_runtime_for_both_functions": True,
        "production_source_modified": False}
    report["timer_source_sha256"] = digest(Path(inspect.getsourcefile(triton.testing.do_bench)))
    report["timer_source"] = str(Path(inspect.getsourcefile(triton.testing.do_bench)).resolve())
    native_guards = 0

    def guard_native_identity():
        global native_guards
        assert native.bincount is original_native
        assert native._bincount_kernel is original_kernel
        assert not getattr(native, "_vllm_fl_kunlunxin_penalties_provider", False)
        assert original_native.__module__ == "vllm.v1.worker.gpu.sample.penalties"
        assert digest(Path(inspect.getsourcefile(original_native))) == "a5e99c71e6ac50ef025b8a7b0b903a1d2679738d8319af9c98bb200389388b29"
        assert sys.modules["triton"] is triton_identity
        assert sys.modules["triton._C.libtriton"] is core_identity
        assert require_in_prefix(core.__file__) == core_path
        native_guards += 1

    guard_native_identity()
    prepared = {}
    for vocab, max_prefill_len in cases:
        key = f"{vocab}-{max_prefill_len}"
        state = contract_states[key]
        metadata = tuple(state[name].cuda() for name in
                         ("mapping", "ids", "prompt_len", "prefill_len"))
        meta_identity = [tensor_identity(value) for value in metadata]
        words = (vocab + 31) // 32
        backings = {}
        callables = {}
        for implementation, function in (("native", original_native), ("gems", candidate_function)):
            packed = state["packed"].cuda()
            counts = state["counts"].cuda()
            call_args = (*metadata, packed[:, :words], counts[:, :vocab], max_prefill_len)
            def launch(function=function, call_args=call_args):
                function(*call_args)
            backings[implementation] = (packed, counts)
            callables[implementation] = launch
        assert backings["native"][0].data_ptr() != backings["gems"][0].data_ptr()
        assert backings["native"][1].data_ptr() != backings["gems"][1].data_ptr()
        prepared[key] = {"state": state, "metadata": metadata,
                         "input_identity": meta_identity, "backings": backings,
                         "callables": callables, "vocab": vocab,
                         "max_prefill_len": max_prefill_len}

    def validate_outputs(key, implementation):
        item = prepared[key]
        state = item["state"]
        packed, counts = item["backings"][implementation]
        torch.cuda.synchronize()
        torch.testing.assert_close(packed.cpu(), state["expected_packed"], rtol=0, atol=0)
        torch.testing.assert_close(counts.cpu(), state["expected_counts"], rtol=0, atol=0)
        assert [tensor_identity(value) for value in item["metadata"]] == item["input_identity"]
        words = (item["vocab"] + 31) // 32
        assert list(packed[:, :words].stride()) == [words + 2, 1]
        assert list(counts[:, :item["vocab"]].stride()) == [item["vocab"] + 5, 1]
        guard_native_identity()

    report["paired_functional_checks"] = []
    # Compile and validate every original case for both callables before any
    # timing; no dtype/shape/empty-case filtering or weakened integer oracle.
    for vocab, max_prefill_len in cases:
        key = f"{vocab}-{max_prefill_len}"
        for implementation in ("native", "gems"):
            for functional_repeat in range(3):
                guard_native_identity()
                prepared[key]["callables"][implementation]()
                validate_outputs(key, implementation)
                report["paired_functional_checks"].append({"case": key,
                    "implementation": implementation, "repeat": functional_repeat,
                    "full_backing_integer_oracle": "pass", "input_identity_unchanged": True,
                    "unexpected_accumulation": False})
    report["performance"] = []
    if not args.accuracy_only:
        import statistics
        for vocab, max_prefill_len in cases:
            key = f"{vocab}-{max_prefill_len}"
            rounds = []
            for pair in range(3):
                order = ("native", "gems") if pair % 2 == 0 else ("gems", "native")
                latencies = {}
                for implementation in order:
                    guard_native_identity()
                    latency = triton.testing.do_bench(
                        prepared[key]["callables"][implementation],
                        warmup=1000, rep=100, return_mode="median")
                    latencies[implementation] = float(latency)
                    assert latencies[implementation] > 0
                    validate_outputs(key, implementation)
                rounds.append({"pair": pair, "order": order,
                    "native_ms": latencies["native"], "gems_ms": latencies["gems"],
                    "speedup": latencies["native"] / latencies["gems"]})
            native_ms = statistics.median(row["native_ms"] for row in rounds)
            gems_ms = statistics.median(row["gems_ms"] for row in rounds)
            paired_speedup_median = statistics.median(row["speedup"] for row in rounds)
            result = {"vocab": vocab, "max_prefill_len": max_prefill_len,
                "rounds": rounds, "native_ms_median": native_ms,
                "gems_ms_median": gems_ms, "speedup": paired_speedup_median,
                "ratio_of_latency_medians_secondary": native_ms / gems_ms,
                "threshold": 0.9, "pass": paired_speedup_median >= 0.9}
            report["performance"].append(result)
            print(json.dumps({"bincount_G6_case": result}), flush=True)
    guard_native_identity()
    report["native_identity_guards_passed"] = native_guards
    report["bincount_G6"] = "not_run_accuracy_only" if args.accuracy_only else (
        "pass" if all(row["pass"] for row in report["performance"]) else "fail")
    report["operator_scope"] = "bincount only; does not qualify grammar/penalties or all of PR1248"

    report["cache_files_after"] = sum(p.is_file() for p in cache.rglob("*"))
    report["result"] = "pass" if args.accuracy_only or report["bincount_G6"] == "pass" else "fail"
except Exception as exc:
    report["result"] = "fail"
    report["error"] = {"type": type(exc).__name__, "message": str(exc)}
    traceback.print_exc()
finally:
    Path(args.output).write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2), flush=True)
sys.exit(0 if report.get("result") == "pass" else 1)
