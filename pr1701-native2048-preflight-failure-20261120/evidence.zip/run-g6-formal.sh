#!/bin/bash
set -euo pipefail
task=/data/pr1701-bincount-g6-20261120
name=codex-pr1701-bincount-g6-formal
image=harbor.baai.ac.cn/plugin/vllm-plugin-fl@sha256:93caedbfc36d665c2e7d9f70a38bbb2501a860c9389be660888b0b6d66bc4402
exec 9>/tmp/codex-p800-4-6.lock
flock -n 9
mkdir -p "$task/results-g6"
test -d "$task/results-g6/cache-bincount-g6"
xpu-smi > "$task/results-g6/gpu-before.smi"
python3 - "$task/results-g6/gpu-before.smi" <<'PY'
from pathlib import Path
import re, sys
text = Path(sys.argv[1]).read_text(); lines = text.splitlines(); seen = {}
for i, line in enumerate(lines):
    m = re.match(r'\|\s+([46])\s+P800\b', line)
    if m: seen[int(m.group(1))] = int(re.search(r'(\d+)MiB\s*/', lines[i+1]).group(1))
assert seen == {4: 0, 6: 0}, seen
assert not re.search(r'^\|\s+[46]\s+\d+', text.split('| Processes:', 1)[1], re.M)
PY
if docker inspect "$name" >/dev/null 2>&1; then exit 13; fi
finish() {
  if [[ "$(docker inspect --format '{{index .Config.Labels "codex.xpu071candidate"}}' "$name" 2>/dev/null || true)" == bincount-g6-formal ]]; then docker stop -t 10 "$name" >/dev/null 2>&1 || true; fi
  xpu-smi > "$task/results-g6/gpu-after.smi"
}
trap finish EXIT
result=0
timeout --signal=TERM --kill-after=15s 300s docker run --rm --pull=never --name "$name" --label codex.xpu071candidate=bincount-g6-formal --runtime=runc --cpus=4 --memory=16g --network host --ipc host --security-opt seccomp=unconfined --device /dev/xpuctrl --device /dev/xpu4 --device /dev/xdrdrv --ulimit memlock=-1 --ulimit core=0 -v /data/pr1701-flagtree071-build-20261120/prefix-scalar-mask-release-on:/compilerrelease:ro -v /data/pr1701-flagtree071-build-20261120/source-scalar-mask-release-on:/sourcerelease:ro -v "$task:/probe:ro" -v "$task/results-g6:/results" -e CUDA_VISIBLE_DEVICES=0 --entrypoint /bin/bash "$image" -ec '
  source /etc/bash_env.sh
  unset BASH_ENV VLLM_FL_FLAGOS_WHITELIST VLLM_FL_FLAGOS_BLACKLIST VLLM_FL_FLAGOS_BLACKLIST_APPEND FLAGCX_PATH
  export PATH=/flagos/bin:$PATH PYTHONPATH=/compilerrelease PYTHONDONTWRITEBYTECODE=1 VLLM_PLUGINS="" USE_FLAGGEMS=0
  export TRITON_CACHE_DIR=/results/cache-bincount-g6 TORCH_EXTENSIONS_DIR=/results/cache-torch071
  unset MLIR_ENABLE_DUMP MLIR_DUMP_PATH
  export TRITON_STORE_BINARY_ONLY=0
  printf "TRITON_STORE_BINARY_ONLY=%s\n" "$TRITON_STORE_BINARY_ONLY"
  python /probe/native-bincount-g6.py --phase warm --manifest /probe/candidate-release-on-runtime.json --compile-commands /probe/scalar-mask-release-on-compile-commands.json --source-prefix /sourcerelease --prefix /compilerrelease --contract-source /probe/test_v2_penalty_bincount.original.py --output /results/g6-formal.json
' > "$task/results-g6/formal.log" 2>&1 || result=$?
printf '%s\n' "$result" > "$task/results-g6/formal-container.exit"
finish
trap - EXIT
exit "$result"
