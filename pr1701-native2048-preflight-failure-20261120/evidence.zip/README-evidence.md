# Native bincount: final ON numerical preflight failure

This is isolated experimental compiler evidence, not a successful performance gate.

The original vLLM 0.32 native wrapper and PR1248 four test contracts are unchanged. The real native callable is checked before and after provider import. The original native source SHA is `a5e99c71e6ac50ef025b8a7b0b903a1d2679738d8319af9c98bb200389388b29`; the original contract source SHA is `f1a7df5f23efcb06a395695b8001909179e114917644e92f729fce429e6d3015`.

The original minimal fixture passed cold and three warm calls, and the four original contracts passed cold4 plus warm12. The separate G6 accuracy-only process also passed all24 paired native/provider full-backing checks. The fresh formal process then failed its mandatory native numerical preflight: repeat0, vocab151939, max_prefill_len2048 had one incorrect count among607776 backing elements at row1, token31. Its other11 checks passed. No formal timing was executed. This failure is preserved rather than retried to obtain a green result.

The failed2048 native kernel uses grid[2,2], unchanged BLOCK_SIZE1024, default cluster_num12/core_num64 and no one-core flag. Its actual ON LLVM text is concealed (zero bytes). The preserved earlier OFF LLVM/TTXIR corresponds to byte-identical device ELF and xpubin, as does the earlier successful ON-four run. Its count update is GM DMA load, ordinary integer add, and LM DMA store. Cross-program global RMW races are a diagnosis to investigate, not a new accepted reference or a completed fix.

The final ON artifact has source062074712ee9a51f4d900d06ad96363c79fd45e9 and core091beadc8876041fc0dd7edbb00fd8059d78cb799b3d85a2075837995b9bf4e5. Both real binding compile commands have the normal conceal macro enabled. This experimental rebuild records the known source SDK MD5 pin mismatch and the newly verified nlohmann3.11.3 header tree; old OFF actual header-tree byte identity was not recoverable. It is not an exact release reconstruction. Production image, SDK and compiler were not replaced.

Grammar/penalties native compilation remains separately blocked. This single-device evidence does not qualify multihost FULL, NoC behavior, 35B, the entire PR1248 or the backend platform gate.
